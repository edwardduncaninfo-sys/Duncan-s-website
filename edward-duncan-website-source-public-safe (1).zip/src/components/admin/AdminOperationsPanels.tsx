import { Copy, KeyRound, ShieldCheck, Trash2, Upload } from 'lucide-react';
import React, { useState } from 'react';
import type {
  ContactSubmission,
  MediaAsset,
  MediaAssetType,
  SubmissionStatus,
} from '../../types/cms';
import { adminFetch } from '../../utils/adminAuth';
import { ResilientImage } from '../ResilientImage';

// ==========================================
// 1. CONTACT FORM SUBMISSIONS
// ==========================================
interface ContactSubmissionsProps {
  submissions: ContactSubmission[];
  onChange: (next: ContactSubmission[]) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function ContactSubmissionsPanel({
  submissions,
  onChange,
  onNotify,
}: ContactSubmissionsProps) {
  const [filterStatus, setFilterStatus] = useState<'All' | SubmissionStatus>('All');
  const [selected, setSelected] = useState<ContactSubmission | null>(submissions[0] || null);
  const [notesDraft, setNotesDraft] = useState(submissions[0]?.adminNotes || '');
  const [statusDraft, setStatusDraft] = useState<SubmissionStatus>(submissions[0]?.status || 'New');

  const filtered =
    filterStatus === 'All' ? submissions : submissions.filter((s) => s.status === filterStatus);

  const selectSubmission = (sub: ContactSubmission) => {
    setSelected(sub);
    setNotesDraft(sub.adminNotes || '');
    setStatusDraft(sub.status);
  };

  const handleUpdate = async () => {
    if (!selected) return;
    try {
      const res = await adminFetch(`/api/admin/submissions/${selected.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ status: statusDraft, adminNotes: notesDraft }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Update failed.');
      onChange(submissions.map((s) => (s.id === selected.id ? data.submission : s)));
      setSelected(data.submission);
      onNotify('Submission status and notes updated.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Update failed.', true);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await adminFetch(`/api/admin/submissions/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!res.ok) throw new Error('Delete failed.');
      const next = submissions.filter((s) => s.id !== id);
      onChange(next);
      if (selected?.id === id) {
        setSelected(next[0] || null);
      }
      onNotify('Submission deleted.');
    } catch {
      onNotify('Unable to delete submission.', true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-[#0B192C]">
            Contact Form Submissions
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Review incoming author promotion requests, uploaded covers, and manage inquiry status.
          </p>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {(['All', 'New', 'Reviewed', 'Replied', 'Archived'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                filterStatus === st
                  ? 'bg-[#0B192C] text-white'
                  : 'bg-white border border-slate-200 text-slate-600'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {submissions.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-2">
          <p className="font-display text-lg font-semibold text-[#0B192C]">
            No Inquiries Received Yet
          </p>
          <p className="text-sm text-slate-500">
            Author promotion quote requests submitted from the public Contact page will appear here securely.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-2.5">
            {filtered.map((sub) => (
              <button
                key={sub.id}
                type="button"
                onClick={() => selectSubmission(sub)}
                className={`w-full text-left p-4 rounded-xl border transition-colors ${
                  selected?.id === sub.id
                    ? 'bg-[#0B192C] text-white border-[#0B192C]'
                    : 'bg-white border-slate-200 hover:border-[#C59B27]'
                }`}
              >
                <div className="flex items-center justify-between gap-2 text-xs mb-1">
                  <span className={selected?.id === sub.id ? 'text-[#D9B44A] font-semibold' : 'text-[#8F6A10] font-semibold'}>
                    {sub.status}
                  </span>
                  <span className={`font-mono-tabular ${selected?.id === sub.id ? 'text-slate-300' : 'text-slate-400'}`}>
                    {sub.createdAt.slice(0, 10)}
                  </span>
                </div>
                <p className="font-semibold text-sm truncate">{sub.fullName}</p>
                <p className={`text-xs truncate ${selected?.id === sub.id ? 'text-slate-300' : 'text-slate-500'}`}>
                  {sub.bookTitle} · {sub.requestedService}
                </p>
              </button>
            ))}
          </div>

          <div className="lg:col-span-7">
            {selected ? (
              <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
                <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
                  <div>
                    <p className="text-xs text-[#8F6A10] font-semibold">{selected.requestedService}</p>
                    <h3 className="font-display text-xl font-semibold text-[#0B192C] mt-0.5">
                      {selected.bookTitle}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      Submitted by {selected.fullName} ({selected.email})
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleDelete(selected.id)}
                    aria-label="Delete submission"
                    className="p-2 rounded-lg border border-red-200 text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-xs text-slate-400">Genre</p>
                    <p className="font-medium text-slate-800">{selected.bookGenre}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Author Website</p>
                    {selected.authorWebsite ? (
                      <a
                        href={selected.authorWebsite}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-medium text-[#8F6A10] hover:underline break-all"
                      >
                        {selected.authorWebsite}
                      </a>
                    ) : (
                      <p className="text-slate-500">Not provided</p>
                    )}
                  </div>
                </div>

                <div>
                  <p className="text-xs text-slate-400 mb-1">Message</p>
                  <div className="p-4 rounded-xl bg-[#F8F9FB] border border-slate-200 text-sm text-slate-700 whitespace-pre-wrap leading-relaxed">
                    {selected.message}
                  </div>
                </div>

                {selected.bookCoverUploadUrl && (
                  <div>
                    <p className="text-xs text-slate-400 mb-2">Uploaded Book Cover</p>
                    <div className="w-36 aspect-[3/4] rounded-lg overflow-hidden border border-slate-200">
                      <ResilientImage
                        src={selected.bookCoverUploadUrl}
                        alt={selected.bookTitle}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                )}

                <div className="pt-4 border-t border-slate-100 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Inquiry Status
                      </label>
                      <select
                        value={statusDraft}
                        onChange={(e) => setStatusDraft(e.target.value as SubmissionStatus)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm bg-white"
                      >
                        <option value="New">New</option>
                        <option value="Reviewed">Reviewed</option>
                        <option value="Replied">Replied</option>
                        <option value="Archived">Archived</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Private Owner Notes
                    </label>
                    <textarea
                      rows={3}
                      value={notesDraft}
                      onChange={(e) => setNotesDraft(e.target.value)}
                      placeholder="Internal notes about quote sent, follow-up date..."
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleUpdate}
                    className="px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945]"
                  >
                    Save Inquiry Status & Notes
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
                Select an inquiry from the left list to inspect details.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// 2. MEDIA LIBRARY
// ==========================================
interface MediaLibraryProps {
  mediaLibrary: MediaAsset[];
  onUploaded: (asset: MediaAsset) => void;
  onDeleted: (id: string) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function MediaLibraryPanel({
  mediaLibrary,
  onUploaded,
  onDeleted,
  onNotify,
}: MediaLibraryProps) {
  const [assetType, setAssetType] = useState<MediaAssetType>('book_cover');
  const [title, setTitle] = useState('');
  const [uploading, setUploading] = useState(false);
  const [filterType, setFilterType] = useState<'all' | MediaAssetType>('all');

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('assetType', assetType);
      formData.append('title', title.trim() || file.name);
      const res = await adminFetch('/api/admin/upload', {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed.');
      onUploaded(data.asset);
      setTitle('');
      onNotify('Media file uploaded to library.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Upload failed.', true);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await adminFetch(`/api/admin/media/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!res.ok) throw new Error('Delete failed.');
      onDeleted(id);
      onNotify('Media asset removed.');
    } catch {
      onNotify('Unable to delete asset.', true);
    }
  };

  const copyUrl = (url: string) => {
    navigator.clipboard?.writeText(url);
    onNotify('Asset URL copied to clipboard.');
  };

  const visible =
    filterType === 'all' ? mediaLibrary : mediaLibrary.filter((m) => m.assetType === filterType);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl font-semibold text-[#0B192C]">Media Library</h2>
        <p className="text-sm text-slate-600 mt-1">
          Upload and organize author photos, book covers, promotional banner graphics, and trailer videos.
        </p>
      </div>

      {/* Upload Drop Panel */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <h3 className="font-display text-lg font-semibold text-[#0B192C]">Upload New Media Asset</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Asset Category</label>
            <select
              value={assetType}
              onChange={(e) => setAssetType(e.target.value as MediaAssetType)}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm bg-white"
            >
              <option value="author_photo">Author Photo</option>
              <option value="book_cover">Book Cover</option>
              <option value="banner">Promotional Banner</option>
              <option value="video_trailer">Book Trailer Video</option>
              <option value="general">General Asset</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Asset Label (Optional)</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Author Portrait 2026"
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <label className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] cursor-pointer">
            <Upload className="w-4 h-4 text-[#D9B44A]" />
            <span>{uploading ? 'Uploading...' : 'Select File to Upload'}</span>
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime"
              onChange={handleUpload}
              className="sr-only"
            />
          </label>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-1.5">
        {([
          { id: 'all', label: 'All Assets' },
          { id: 'author_photo', label: 'Author Photos' },
          { id: 'book_cover', label: 'Book Covers' },
          { id: 'banner', label: 'Banners' },
          { id: 'video_trailer', label: 'Video Trailers' },
        ] as const).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilterType(tab.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
              filterType === tab.id
                ? 'bg-[#0B192C] text-white'
                : 'bg-white border border-slate-200 text-slate-600'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {visible.map((asset) => {
          const isVideo = asset.mimeType.startsWith('video/');
          return (
            <div key={asset.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col justify-between">
              <div className="aspect-[4/3] bg-slate-900 flex items-center justify-center overflow-hidden">
                {isVideo ? (
                  <video src={asset.url} controls className="w-full h-full object-contain" />
                ) : (
                  <ResilientImage src={asset.url} alt={asset.title} className="w-full h-full object-cover" />
                )}
              </div>
              <div className="p-3.5 space-y-2">
                <p className="text-xs font-semibold text-[#0B192C] truncate">{asset.title}</p>
                <p className="text-[11px] text-slate-500 font-mono-tabular truncate">
                  {asset.assetType} {asset.sizeBytes > 0 ? `· ${(asset.sizeBytes / 1024).toFixed(0)} KB` : ''}
                </p>
                <div className="pt-2 flex items-center justify-between gap-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => copyUrl(asset.url)}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-[#0B192C] hover:text-[#8F6A10]"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy URL</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(asset.id)}
                    className="text-xs font-semibold text-red-600 hover:underline"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ==========================================
// 3. SECURITY & ACCOUNT SETTINGS
// ==========================================
interface SessionInfo {
  id: string;
  createdAt: string;
  expiresAt: string;
  userAgent: string;
  ipAddress: string;
  isCurrent: boolean;
}

interface SecuritySettingsProps {
  owner: {
    email: string;
    lastLoginAt: string | null;
    updatedAt: string;
    recoveryKeyPreview: string;
  };
  sessions: SessionInfo[];
  onRefresh: () => Promise<void>;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function SecuritySettingsPanel({
  owner,
  sessions,
  onRefresh,
  onNotify,
}: SecuritySettingsProps) {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [newEmail, setNewEmail] = useState(owner.email);
  const [emailPassword, setEmailPassword] = useState('');

  const [recoveryPassword, setRecoveryPassword] = useState('');
  const [revealedKey, setRevealedKey] = useState<string | null>(null);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 8) {
      onNotify('New password must be at least 8 characters long.', true);
      return;
    }
    if (newPassword !== confirmPassword) {
      onNotify('New password confirmation does not match.', true);
      return;
    }
    try {
      const res = await adminFetch('/api/admin/security/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update password.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      onNotify('Owner password updated securely.');
      await onRefresh();
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Password update failed.', true);
    }
  };

  const handleChangeEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await adminFetch('/api/admin/security/change-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ currentPassword: emailPassword, newEmail }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update email.');
      setEmailPassword('');
      onNotify('Owner email updated.');
      await onRefresh();
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Email update failed.', true);
    }
  };

  const handleRegenerateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await adminFetch('/api/admin/security/regenerate-recovery-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ currentPassword: recoveryPassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Unable to regenerate recovery key.');
      setRecoveryPassword('');
      setRevealedKey(data.recoveryKey);
      onNotify('New Owner Recovery Key generated. Save it offline immediately.');
      await onRefresh();
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to regenerate key.', true);
    }
  };

  const handleRevokeSession = async (id: string) => {
    try {
      const res = await adminFetch(`/api/admin/security/sessions/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!res.ok) throw new Error('Failed.');
      onNotify('Session revoked.');
      await onRefresh();
    } catch {
      onNotify('Unable to revoke session.', true);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h2 className="font-display text-2xl font-semibold text-[#0B192C]">
          Security and Account Settings
        </h2>
        <p className="text-sm text-slate-600 mt-1">
          Manage your private owner credentials, recovery key, and active administrative sessions.
        </p>
      </div>

      {/* Account Summary */}
      <div className="bg-[#0B192C] text-white rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-6 h-6 text-[#D9B44A] shrink-0" />
          <div>
            <p className="text-xs text-slate-400">Authorized Owner Account</p>
            <p className="text-base font-semibold">{owner.email}</p>
          </div>
        </div>
        <div className="text-xs text-slate-300 font-mono-tabular space-y-1 sm:text-right">
          <p>Last Sign In: {owner.lastLoginAt ? owner.lastLoginAt.slice(0, 16).replace('T', ' ') : 'Current'}</p>
          <p>Recovery Key: {owner.recoveryKeyPreview}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Change Password */}
        <form onSubmit={handleChangePassword} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <h3 className="font-display text-lg font-semibold text-[#0B192C]">Change Owner Password</h3>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Current Password</label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              New Password (min. 8 chars)
            </label>
            <input
              type="password"
              required
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Confirm New Password</label>
            <input
              type="password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945]"
          >
            Update Password
          </button>
        </form>

        {/* Change Email */}
        <form onSubmit={handleChangeEmail} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <h3 className="font-display text-lg font-semibold text-[#0B192C]">Owner Sign-In Email</h3>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Authorized Email</label>
            <input
              type="email"
              required
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Verify Current Password
            </label>
            <input
              type="password"
              required
              value={emailPassword}
              onChange={(e) => setEmailPassword(e.target.value)}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945]"
          >
            Update Owner Email
          </button>
        </form>
      </div>

      {/* Recovery Key */}
      <form onSubmit={handleRegenerateKey} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex items-center gap-2">
          <KeyRound className="w-5 h-5 text-[#8F6A10]" />
          <h3 className="font-display text-lg font-semibold text-[#0B192C]">Owner Recovery Key</h3>
        </div>
        <p className="text-sm text-slate-600">
          Your Owner Recovery Key authorizes emergency password resets on the Reset Password screen. Regenerating invalidates any previous key.
        </p>

        {revealedKey && (
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 space-y-1">
            <p className="text-xs font-semibold text-amber-900">
              Save this new Recovery Key now — it will not be shown in full again:
            </p>
            <p className="font-mono text-sm font-bold text-[#0B192C] select-all">{revealedKey}</p>
          </div>
        )}

        <div className="flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-[220px]">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Confirm Current Password
            </label>
            <input
              type="password"
              required
              value={recoveryPassword}
              onChange={(e) => setRecoveryPassword(e.target.value)}
              placeholder="Enter current password"
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2 rounded-lg border border-[#0B192C] text-[#0B192C] text-sm font-semibold hover:bg-slate-50"
          >
            Generate New Recovery Key
          </button>
        </div>
      </form>

      {/* Active Sessions */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200">
          <h3 className="font-display text-lg font-semibold text-[#0B192C]">Active Owner Sessions</h3>
        </div>
        <div className="divide-y divide-slate-100">
          {sessions.map((sess) => (
            <div key={sess.id} className="px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-0.5 min-w-0">
                <p className="text-sm font-medium text-[#0B192C] truncate">
                  {sess.isCurrent ? 'Current Browser Session' : 'Authenticated Session'} · {sess.ipAddress}
                </p>
                <p className="text-xs text-slate-500 truncate">{sess.userAgent}</p>
                <p className="text-[11px] font-mono-tabular text-slate-400">
                  Signed in: {sess.createdAt.slice(0, 16).replace('T', ' ')} · Expires: {sess.expiresAt.slice(0, 10)}
                </p>
              </div>
              {!sess.isCurrent && (
                <button
                  type="button"
                  onClick={() => handleRevokeSession(sess.id)}
                  className="px-3.5 py-1.5 rounded-lg border border-red-200 text-xs font-semibold text-red-600 hover:bg-red-50 shrink-0"
                >
                  Revoke Session
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
