import { Edit3, Eye, EyeOff, Plus, Trash2 } from 'lucide-react';
import React, { useState } from 'react';
import {
  PORTFOLIO_CATEGORIES,
  type AuthorProfile,
  type FeaturedBook,
  type MediaAsset,
  type PortfolioCategory,
  type PortfolioItem,
  type ServiceItem,
  type TestimonialItem,
} from '../../types/cms';
import { ResilientImage } from '../ResilientImage';
import { adminFetch } from '../../utils/adminAuth';
import { MediaField } from './MediaField';

// ==========================================
// 1. MANAGE SERVICES
// ==========================================
interface ManageServicesProps {
  services: ServiceItem[];
  mediaLibrary: MediaAsset[];
  onMediaUploaded: (asset: MediaAsset) => void;
  onChange: (next: ServiceItem[]) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function ManageServicesPanel({
  services,
  mediaLibrary,
  onMediaUploaded,
  onChange,
  onNotify,
}: ManageServicesProps) {
  const [editing, setEditing] = useState<Partial<ServiceItem> | null>(null);
  const [deliverablesText, setDeliverablesText] = useState('');
  const [saving, setSaving] = useState(false);

  const openNew = () => {
    setEditing({
      title: '',
      shortDescription: '',
      fullDescription: '',
      imageUrl: '/src/assets/images/service_author_spotlight_1795012457843.jpg',
      featuredOnHome: true,
      order: services.length + 1,
      active: true,
    });
    setDeliverablesText('');
  };

  const openEdit = (svc: ServiceItem) => {
    setEditing({ ...svc });
    setDeliverablesText(svc.deliverables.join('\n'));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing?.title?.trim()) {
      onNotify('Service title is required.', true);
      return;
    }
    setSaving(true);
    try {
      const payload = {
        ...editing,
        deliverables: deliverablesText
          .split('\n')
          .map((d) => d.trim())
          .filter(Boolean),
      };
      const isEdit = Boolean(editing.id);
      const res = await adminFetch(isEdit ? `/api/admin/services/${editing.id}` : '/api/admin/services', {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save service.');

      if (isEdit) {
        onChange(services.map((s) => (s.id === data.service.id ? data.service : s)));
      } else {
        onChange([...services, data.service]);
      }
      setEditing(null);
      onNotify(isEdit ? 'Service updated.' : 'New service added.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Save failed.', true);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await adminFetch(`/api/admin/services/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!res.ok) throw new Error('Delete failed.');
      onChange(services.filter((s) => s.id !== id));
      onNotify('Service deleted.');
    } catch {
      onNotify('Unable to delete service.', true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-[#0B192C]">Manage Services</h2>
          <p className="text-sm text-slate-600 mt-1">Add, edit, reorder, or remove book promotion services.</p>
        </div>
        <button
          type="button"
          onClick={openNew}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#0B192C] text-white text-xs font-semibold hover:bg-[#132945]"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Service</span>
        </button>
      </div>

      {editing && (
        <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-lg font-semibold text-[#0B192C]">
              {editing.id ? 'Edit Service' : 'Create Service'}
            </h3>
            <button type="button" onClick={() => setEditing(null)} className="text-xs text-slate-500 hover:text-slate-900">
              Cancel
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Service Title *</label>
              <input
                type="text"
                required
                value={editing.title || ''}
                onChange={(e) => setEditing({ ...editing, title: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Display Order</label>
              <input
                type="number"
                value={editing.order || 1}
                onChange={(e) => setEditing({ ...editing, order: Number(e.target.value) })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm font-mono-tabular"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Short Summary (for cards)</label>
            <input
              type="text"
              value={editing.shortDescription || ''}
              onChange={(e) => setEditing({ ...editing, shortDescription: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Full Description</label>
            <textarea
              rows={3}
              value={editing.fullDescription || ''}
              onChange={(e) => setEditing({ ...editing, fullDescription: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Deliverables (one per line)</label>
            <textarea
              rows={4}
              value={deliverablesText}
              onChange={(e) => setDeliverablesText(e.target.value)}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <MediaField
            label="Service Image"
            value={editing.imageUrl || ''}
            onChange={(url) => setEditing({ ...editing, imageUrl: url })}
            assetType="banner"
            mediaLibrary={mediaLibrary}
            onMediaUploaded={onMediaUploaded}
          />
          <div className="flex flex-wrap gap-6 pt-2">
            <label className="inline-flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={editing.featuredOnHome ?? true}
                onChange={(e) => setEditing({ ...editing, featuredOnHome: e.target.checked })}
              />
              <span>Feature on Homepage</span>
            </label>
            <label className="inline-flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={editing.active ?? true}
                onChange={(e) => setEditing({ ...editing, active: e.target.checked })}
              />
              <span>Visible on Public Services Page</span>
            </label>
          </div>
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945]"
          >
            {saving ? 'Saving...' : 'Save Service'}
          </button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {services.map((svc) => (
          <div key={svc.id} className="bg-white border border-slate-200 rounded-xl p-5 flex gap-4 justify-between">
            <div className="space-y-1.5 min-w-0">
              <p className="text-xs text-[#8F6A10] font-mono-tabular">
                Order #{svc.order} · {svc.active ? 'Published' : 'Hidden'}
                {svc.featuredOnHome ? ' · Featured' : ''}
              </p>
              <h3 className="font-display text-lg font-semibold text-[#0B192C] truncate">{svc.title}</h3>
              <p className="text-xs text-slate-600 line-clamp-2">{svc.shortDescription}</p>
            </div>
            <div className="flex items-start gap-2 shrink-0">
              <button
                type="button"
                onClick={() => openEdit(svc)}
                aria-label={`Edit ${svc.title}`}
                className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
              >
                <Edit3 className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => handleDelete(svc.id)}
                aria-label={`Delete ${svc.title}`}
                className="p-2 rounded-lg border border-slate-200 text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// 2. MANAGE PORTFOLIO
// ==========================================
interface ManagePortfolioProps {
  portfolio: PortfolioItem[];
  mediaLibrary: MediaAsset[];
  onMediaUploaded: (asset: MediaAsset) => void;
  onChange: (next: PortfolioItem[]) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function ManagePortfolioPanel({
  portfolio,
  mediaLibrary,
  onMediaUploaded,
  onChange,
  onNotify,
}: ManagePortfolioProps) {
  const [editing, setEditing] = useState<Partial<PortfolioItem> | null>(null);
  const [filterCat, setFilterCat] = useState<'All' | PortfolioCategory>('All');
  const [saving, setSaving] = useState(false);

  const visibleItems =
    filterCat === 'All' ? portfolio : portfolio.filter((p) => p.category === filterCat);

  const openNew = () => {
    setEditing({
      projectTitle: '',
      authorName: '',
      bookTitle: '',
      bookCoverUrl: '',
      bannerImageUrl: '',
      videoUrl: '',
      videoType: 'none',
      description: '',
      category: 'Promotional Projects',
      publicationDate: new Date().toISOString().slice(0, 10),
      featuredOnHome: true,
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing?.projectTitle?.trim()) {
      onNotify('Project title is required.', true);
      return;
    }
    setSaving(true);
    try {
      const isEdit = Boolean(editing.id);
      const res = await adminFetch(isEdit ? `/api/admin/portfolio/${editing.id}` : '/api/admin/portfolio', {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          ...editing,
          videoType: editing.videoUrl
            ? editing.videoUrl.startsWith('/uploads/')
              ? 'upload'
              : 'external'
            : 'none',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save project.');
      if (isEdit) {
        onChange(portfolio.map((p) => (p.id === data.item.id ? data.item : p)));
      } else {
        onChange([data.item, ...portfolio]);
      }
      setEditing(null);
      onNotify(isEdit ? 'Portfolio project updated.' : 'Portfolio project added.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Save failed.', true);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await adminFetch(`/api/admin/portfolio/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!res.ok) throw new Error('Delete failed.');
      onChange(portfolio.filter((p) => p.id !== id));
      onNotify('Portfolio item removed.');
    } catch {
      onNotify('Unable to delete item.', true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-[#0B192C]">Manage Portfolio</h2>
          <p className="text-sm text-slate-600 mt-1">
            Create, edit, or delete portfolio showcases across all 7 promotional categories.
          </p>
        </div>
        <button
          type="button"
          onClick={openNew}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#0B192C] text-white text-xs font-semibold hover:bg-[#132945]"
        >
          <Plus className="w-4 h-4" />
          <span>Add Portfolio Project</span>
        </button>
      </div>

      <div className="flex flex-wrap gap-1.5">
        <button
          type="button"
          onClick={() => setFilterCat('All')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
            filterCat === 'All' ? 'bg-[#0B192C] text-white' : 'bg-white border border-slate-200 text-slate-600'
          }`}
        >
          All ({portfolio.length})
        </button>
        {PORTFOLIO_CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setFilterCat(cat)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
              filterCat === cat ? 'bg-[#0B192C] text-white' : 'bg-white border border-slate-200 text-slate-600'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {editing && (
        <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-lg font-semibold text-[#0B192C]">
              {editing.id ? 'Edit Portfolio Project' : 'New Portfolio Project'}
            </h3>
            <button type="button" onClick={() => setEditing(null)} className="text-xs text-slate-500">
              Cancel
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Project Title *</label>
              <input
                type="text"
                required
                value={editing.projectTitle || ''}
                onChange={(e) => setEditing({ ...editing, projectTitle: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
              <select
                value={editing.category || 'Promotional Projects'}
                onChange={(e) => setEditing({ ...editing, category: e.target.value as PortfolioCategory })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm bg-white"
              >
                {PORTFOLIO_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Book Title</label>
              <input
                type="text"
                value={editing.bookTitle || ''}
                onChange={(e) => setEditing({ ...editing, bookTitle: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Author Name</label>
              <input
                type="text"
                value={editing.authorName || ''}
                onChange={(e) => setEditing({ ...editing, authorName: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <MediaField
              label="Book Cover Image"
              value={editing.bookCoverUrl || ''}
              onChange={(url) => setEditing({ ...editing, bookCoverUrl: url })}
              assetType="book_cover"
              mediaLibrary={mediaLibrary}
              onMediaUploaded={onMediaUploaded}
            />
            <MediaField
              label="Promotional Banner Image"
              value={editing.bannerImageUrl || ''}
              onChange={(url) => setEditing({ ...editing, bannerImageUrl: url })}
              assetType="banner"
              mediaLibrary={mediaLibrary}
              onMediaUploaded={onMediaUploaded}
            />
          </div>

          <MediaField
            label="Trailer Video Upload or External Link (Optional)"
            value={editing.videoUrl || ''}
            onChange={(url) => setEditing({ ...editing, videoUrl: url })}
            assetType="video_trailer"
            accept="video/mp4,video/webm,video/quicktime"
            mediaLibrary={mediaLibrary}
            onMediaUploaded={onMediaUploaded}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Publication Date</label>
              <input
                type="date"
                value={editing.publicationDate || ''}
                onChange={(e) => setEditing({ ...editing, publicationDate: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm font-mono-tabular"
              />
            </div>
            <div className="flex items-end pb-2">
              <label className="inline-flex items-center gap-2 text-sm text-slate-700">
                <input
                  type="checkbox"
                  checked={editing.featuredOnHome ?? false}
                  onChange={(e) => setEditing({ ...editing, featuredOnHome: e.target.checked })}
                />
                <span>Feature on Homepage Showcase</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Project Description</label>
            <textarea
              rows={3}
              value={editing.description || ''}
              onChange={(e) => setEditing({ ...editing, description: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945]"
          >
            {saving ? 'Saving...' : 'Save Portfolio Project'}
          </button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {visibleItems.map((item) => (
          <div key={item.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col justify-between">
            <div className="aspect-[16/10] bg-slate-100">
              <ResilientImage
                src={item.bannerImageUrl || item.bookCoverUrl}
                alt={item.projectTitle}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
              <div className="space-y-1">
                <p className="text-[11px] font-medium text-[#8F6A10]">
                  {item.category} · {item.publicationDate}
                </p>
                <h3 className="font-display text-base font-semibold text-[#0B192C]">
                  {item.projectTitle}
                </h3>
                <p className="text-xs text-slate-500">
                  {item.bookTitle} {item.authorName ? `· ${item.authorName}` : ''}
                </p>
              </div>
              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditing({ ...item })}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(item.id)}
                  className="px-3 py-1.5 rounded-lg border border-red-200 text-xs font-semibold text-red-600 hover:bg-red-50"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// 3. MANAGE FEATURED BOOKS
// ==========================================
interface ManageBooksProps {
  books: FeaturedBook[];
  mediaLibrary: MediaAsset[];
  onMediaUploaded: (asset: MediaAsset) => void;
  onChange: (next: FeaturedBook[]) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function ManageFeaturedBooksPanel({
  books,
  mediaLibrary,
  onMediaUploaded,
  onChange,
  onNotify,
}: ManageBooksProps) {
  const [editing, setEditing] = useState<Partial<FeaturedBook> | null>(null);
  const [saving, setSaving] = useState(false);

  const openNew = () => {
    setEditing({
      bookTitle: '',
      authorName: '',
      genre: '',
      shortDescription: '',
      promotionalNotes: '',
      bookCoverUrl: '',
      promotionalBannerUrl: '',
      trailerUrl: '',
      purchaseLink: '',
      spotlightStory: '',
      featuredOnHome: true,
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing?.bookTitle?.trim()) {
      onNotify('Book title is required.', true);
      return;
    }
    setSaving(true);
    try {
      const isEdit = Boolean(editing.id);
      const res = await adminFetch(isEdit ? `/api/admin/books/${editing.id}` : '/api/admin/books', {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(editing),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save featured book.');
      if (isEdit) {
        onChange(books.map((b) => (b.id === data.book.id ? data.book : b)));
      } else {
        onChange([data.book, ...books]);
      }
      setEditing(null);
      onNotify(isEdit ? 'Featured book updated.' : 'Featured book added.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Save failed.', true);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await adminFetch(`/api/admin/books/${id}`, { method: 'DELETE', credentials: 'include' });
      if (!res.ok) throw new Error('Delete failed.');
      onChange(books.filter((b) => b.id !== id));
      onNotify('Featured book deleted.');
    } catch {
      onNotify('Unable to delete book.', true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-[#0B192C]">Manage Featured Books</h2>
          <p className="text-sm text-slate-600 mt-1">
            Add and manage books showcased with covers, promotional features, and Amazon links.
          </p>
        </div>
        <button
          type="button"
          onClick={openNew}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#0B192C] text-white text-xs font-semibold hover:bg-[#132945]"
        >
          <Plus className="w-4 h-4" />
          <span>Add Featured Book</span>
        </button>
      </div>

      {editing && (
        <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-lg font-semibold text-[#0B192C]">
              {editing.id ? 'Edit Featured Book' : 'Add Featured Book'}
            </h3>
            <button type="button" onClick={() => setEditing(null)} className="text-xs text-slate-500">
              Cancel
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Book Title *</label>
              <input
                type="text"
                required
                value={editing.bookTitle || ''}
                onChange={(e) => setEditing({ ...editing, bookTitle: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Author Name</label>
              <input
                type="text"
                value={editing.authorName || ''}
                onChange={(e) => setEditing({ ...editing, authorName: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Genre</label>
              <input
                type="text"
                value={editing.genre || ''}
                onChange={(e) => setEditing({ ...editing, genre: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <MediaField
              label="Book Cover"
              value={editing.bookCoverUrl || ''}
              onChange={(url) => setEditing({ ...editing, bookCoverUrl: url })}
              assetType="book_cover"
              mediaLibrary={mediaLibrary}
              onMediaUploaded={onMediaUploaded}
            />
            <MediaField
              label="Promotional Banner"
              value={editing.promotionalBannerUrl || ''}
              onChange={(url) => setEditing({ ...editing, promotionalBannerUrl: url })}
              assetType="banner"
              mediaLibrary={mediaLibrary}
              onMediaUploaded={onMediaUploaded}
            />
          </div>

          <MediaField
            label="Trailer Video (Optional)"
            value={editing.trailerUrl || ''}
            onChange={(url) => setEditing({ ...editing, trailerUrl: url })}
            assetType="video_trailer"
            accept="video/mp4,video/webm,video/quicktime"
            mediaLibrary={mediaLibrary}
            onMediaUploaded={onMediaUploaded}
          />

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Amazon or Book Purchase Link</label>
            <input
              type="url"
              value={editing.purchaseLink || ''}
              onChange={(e) => setEditing({ ...editing, purchaseLink: e.target.value })}
              placeholder="https://www.amazon.com/dp/..."
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Short Book Description</label>
            <textarea
              rows={2}
              value={editing.shortDescription || ''}
              onChange={(e) => setEditing({ ...editing, shortDescription: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Spotlight Story & Promotional Materials Notes</label>
            <textarea
              rows={3}
              value={editing.spotlightStory || ''}
              onChange={(e) => setEditing({ ...editing, spotlightStory: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Promotional Scope Summary</label>
            <input
              type="text"
              value={editing.promotionalNotes || ''}
              onChange={(e) => setEditing({ ...editing, promotionalNotes: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <label className="inline-flex items-center gap-2 text-sm text-slate-700">
            <input
              type="checkbox"
              checked={editing.featuredOnHome ?? true}
              onChange={(e) => setEditing({ ...editing, featuredOnHome: e.target.checked })}
            />
            <span>Display on Homepage</span>
          </label>

          <div>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945]"
            >
              {saving ? 'Saving...' : 'Save Featured Book'}
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {books.map((book) => (
          <div key={book.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col justify-between">
            <div className="aspect-[4/3] bg-slate-100">
              <ResilientImage src={book.bookCoverUrl} alt={book.bookTitle} className="w-full h-full object-cover" />
            </div>
            <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
              <div className="space-y-1">
                <p className="text-[11px] font-medium text-[#8F6A10]">{book.genre}</p>
                <h3 className="font-display text-base font-semibold text-[#0B192C]">{book.bookTitle}</h3>
                <p className="text-xs text-slate-500">{book.authorName}</p>
              </div>
              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditing({ ...book })}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(book.id)}
                  className="px-3 py-1.5 rounded-lg border border-red-200 text-xs font-semibold text-red-600 hover:bg-red-50"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// 4. MANAGE AUTHORS
// ==========================================
interface ManageAuthorsProps {
  authors: AuthorProfile[];
  mediaLibrary: MediaAsset[];
  onMediaUploaded: (asset: MediaAsset) => void;
  onChange: (next: AuthorProfile[]) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function ManageAuthorsPanel({
  authors,
  mediaLibrary,
  onMediaUploaded,
  onChange,
  onNotify,
}: ManageAuthorsProps) {
  const [editing, setEditing] = useState<Partial<AuthorProfile> | null>(null);
  const [genresText, setGenresText] = useState('');
  const [saving, setSaving] = useState(false);

  const openNew = () => {
    setEditing({
      fullName: '',
      penName: '',
      bio: '',
      photoUrl: '',
      website: '',
      socialLink: '',
      featuredBooksCount: 1,
    });
    setGenresText('');
  };

  const openEdit = (author: AuthorProfile) => {
    setEditing({ ...author });
    setGenresText(author.genres.join(', '));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing?.fullName?.trim()) {
      onNotify('Author name is required.', true);
      return;
    }
    setSaving(true);
    try {
      const isEdit = Boolean(editing.id);
      const res = await adminFetch(isEdit ? `/api/admin/authors/${editing.id}` : '/api/admin/authors', {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          ...editing,
          genres: genresText.split(',').map((g) => g.trim()).filter(Boolean),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save author.');
      if (isEdit) {
        onChange(authors.map((a) => (a.id === data.author.id ? data.author : a)));
      } else {
        onChange([data.author, ...authors]);
      }
      setEditing(null);
      onNotify(isEdit ? 'Author profile updated.' : 'Author profile added.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Save failed.', true);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await adminFetch(`/api/admin/authors/${id}`, { method: 'DELETE', credentials: 'include' });
      if (!res.ok) throw new Error('Delete failed.');
      onChange(authors.filter((a) => a.id !== id));
      onNotify('Author removed.');
    } catch {
      onNotify('Unable to delete author.', true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-[#0B192C]">Manage Authors</h2>
          <p className="text-sm text-slate-600 mt-1">Maintain author directory profiles, bios, and links.</p>
        </div>
        <button
          type="button"
          onClick={openNew}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#0B192C] text-white text-xs font-semibold hover:bg-[#132945]"
        >
          <Plus className="w-4 h-4" />
          <span>Add Author</span>
        </button>
      </div>

      {editing && (
        <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-lg font-semibold text-[#0B192C]">
              {editing.id ? 'Edit Author Profile' : 'New Author Profile'}
            </h3>
            <button type="button" onClick={() => setEditing(null)} className="text-xs text-slate-500">
              Cancel
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name *</label>
              <input
                type="text"
                required
                value={editing.fullName || ''}
                onChange={(e) => setEditing({ ...editing, fullName: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Genres (comma-separated)</label>
              <input
                type="text"
                value={genresText}
                onChange={(e) => setGenresText(e.target.value)}
                placeholder="Literary Fiction, Mystery"
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Author Website</label>
              <input
                type="url"
                value={editing.website || ''}
                onChange={(e) => setEditing({ ...editing, website: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Social Media Link</label>
              <input
                type="url"
                value={editing.socialLink || ''}
                onChange={(e) => setEditing({ ...editing, socialLink: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
          </div>
          <MediaField
            label="Author Photograph"
            value={editing.photoUrl || ''}
            onChange={(url) => setEditing({ ...editing, photoUrl: url })}
            assetType="author_photo"
            mediaLibrary={mediaLibrary}
            onMediaUploaded={onMediaUploaded}
          />
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Author Biography</label>
            <textarea
              rows={3}
              value={editing.bio || ''}
              onChange={(e) => setEditing({ ...editing, bio: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945]"
          >
            {saving ? 'Saving...' : 'Save Author'}
          </button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {authors.map((author) => (
          <div key={author.id} className="bg-white border border-slate-200 rounded-xl p-5 flex items-start justify-between gap-4">
            <div className="flex items-start gap-4 min-w-0">
              <div className="w-14 h-14 rounded-lg overflow-hidden border border-slate-200 shrink-0">
                <ResilientImage src={author.photoUrl} alt={author.fullName} className="w-full h-full object-cover" />
              </div>
              <div className="min-w-0 space-y-1">
                <h3 className="font-display text-base font-semibold text-[#0B192C] truncate">{author.fullName}</h3>
                <p className="text-xs text-[#8F6A10] truncate">{author.genres.join(' · ')}</p>
                <p className="text-xs text-slate-600 line-clamp-2">{author.bio}</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => openEdit(author)}
                className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
              >
                <Edit3 className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => handleDelete(author.id)}
                className="p-2 rounded-lg border border-slate-200 text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==========================================
// 5. MANAGE TESTIMONIALS
// ==========================================
interface ManageTestimonialsProps {
  testimonials: TestimonialItem[];
  mediaLibrary: MediaAsset[];
  onMediaUploaded: (asset: MediaAsset) => void;
  onChange: (next: TestimonialItem[]) => void;
  onNotify: (msg: string, isError?: boolean) => void;
}

export function ManageTestimonialsPanel({
  testimonials,
  mediaLibrary,
  onMediaUploaded,
  onChange,
  onNotify,
}: ManageTestimonialsProps) {
  const [editing, setEditing] = useState<Partial<TestimonialItem> | null>(null);
  const [saving, setSaving] = useState(false);

  const openNew = () => {
    setEditing({
      authorName: '',
      authorPhotoUrl: '',
      bookTitle: '',
      bookCoverUrl: '',
      testimonialText: '',
      authorLink: '',
      rating: 5,
      published: true,
      isPlaceholder: false,
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing?.authorName?.trim() || !editing?.testimonialText?.trim()) {
      onNotify('Author name and testimonial text are required.', true);
      return;
    }
    setSaving(true);
    try {
      const isEdit = Boolean(editing.id);
      const res = await adminFetch(
        isEdit ? `/api/admin/testimonials/${editing.id}` : '/api/admin/testimonials',
        {
          method: isEdit ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(editing),
        },
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save testimonial.');
      if (isEdit) {
        onChange(testimonials.map((t) => (t.id === data.testimonial.id ? data.testimonial : t)));
      } else {
        onChange([data.testimonial, ...testimonials]);
      }
      setEditing(null);
      onNotify(isEdit ? 'Testimonial updated.' : 'Testimonial added.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Save failed.', true);
    } finally {
      setSaving(false);
    }
  };

  const togglePublish = async (item: TestimonialItem) => {
    try {
      const res = await adminFetch(`/api/admin/testimonials/${item.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ published: !item.published }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error('Update failed.');
      onChange(testimonials.map((t) => (t.id === item.id ? data.testimonial : t)));
      onNotify(data.testimonial.published ? 'Testimonial published.' : 'Testimonial unpublished.');
    } catch {
      onNotify('Failed to update status.', true);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await adminFetch(`/api/admin/testimonials/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!res.ok) throw new Error('Delete failed.');
      onChange(testimonials.filter((t) => t.id !== id));
      onNotify('Testimonial deleted.');
    } catch {
      onNotify('Failed to delete testimonial.', true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-[#0B192C]">Manage Testimonials</h2>
          <p className="text-sm text-slate-600 mt-1">
            Add genuine author feedback, publish or unpublish testimonials, and replace initial placeholders.
          </p>
        </div>
        <button
          type="button"
          onClick={openNew}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#0B192C] text-white text-xs font-semibold hover:bg-[#132945]"
        >
          <Plus className="w-4 h-4" />
          <span>Add Author Testimonial</span>
        </button>
      </div>

      {editing && (
        <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-lg font-semibold text-[#0B192C]">
              {editing.id ? 'Edit Testimonial' : 'Add Genuine Testimonial'}
            </h3>
            <button type="button" onClick={() => setEditing(null)} className="text-xs text-slate-500">
              Cancel
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Author Full Name *</label>
              <input
                type="text"
                required
                value={editing.authorName || ''}
                onChange={(e) => setEditing({ ...editing, authorName: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Book Title</label>
              <input
                type="text"
                value={editing.bookTitle || ''}
                onChange={(e) => setEditing({ ...editing, bookTitle: e.target.value })}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Rating (1-5 Optional)</label>
              <input
                type="number"
                min={1}
                max={5}
                value={editing.rating ?? ''}
                onChange={(e) =>
                  setEditing({
                    ...editing,
                    rating: e.target.value ? Number(e.target.value) : undefined,
                  })
                }
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm font-mono-tabular"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <MediaField
              label="Author Photograph"
              value={editing.authorPhotoUrl || ''}
              onChange={(url) => setEditing({ ...editing, authorPhotoUrl: url })}
              assetType="author_photo"
              mediaLibrary={mediaLibrary}
              onMediaUploaded={onMediaUploaded}
            />
            <MediaField
              label="Book Cover (Optional)"
              value={editing.bookCoverUrl || ''}
              onChange={(url) => setEditing({ ...editing, bookCoverUrl: url })}
              assetType="book_cover"
              mediaLibrary={mediaLibrary}
              onMediaUploaded={onMediaUploaded}
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Author Website or Social Link (Optional)</label>
            <input
              type="url"
              value={editing.authorLink || ''}
              onChange={(e) => setEditing({ ...editing, authorLink: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Testimonial Quote *</label>
            <textarea
              rows={3}
              required
              value={editing.testimonialText || ''}
              onChange={(e) => setEditing({ ...editing, testimonialText: e.target.value })}
              className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <div className="flex flex-wrap gap-6">
            <label className="inline-flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={editing.published ?? true}
                onChange={(e) => setEditing({ ...editing, published: e.target.checked })}
              />
              <span>Published on Website</span>
            </label>
            <label className="inline-flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={editing.isPlaceholder ?? false}
                onChange={(e) => setEditing({ ...editing, isPlaceholder: e.target.checked })}
              />
              <span>Mark as Placeholder</span>
            </label>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945]"
          >
            {saving ? 'Saving...' : 'Save Testimonial'}
          </button>
        </form>
      )}

      <div className="space-y-3">
        {testimonials.map((t) => (
          <div key={t.id} className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <p className="text-xs font-medium text-[#8F6A10]">
                {t.published ? 'Published' : 'Unpublished'}
                {t.isPlaceholder ? ' · Placeholder' : ' · Verified Client'}
                {t.bookTitle ? ` · ${t.bookTitle}` : ''}
              </p>
              <h3 className="font-display text-base font-semibold text-[#0B192C]">{t.authorName}</h3>
              <p className="text-sm text-slate-600 line-clamp-2">“{t.testimonialText}”</p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => togglePublish(t)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                {t.published ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{t.published ? 'Unpublish' : 'Publish'}</span>
              </button>
              <button
                type="button"
                onClick={() => setEditing({ ...t })}
                className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                Edit
              </button>
              <button
                type="button"
                onClick={() => handleDelete(t.id)}
                className="px-3 py-1.5 rounded-lg border border-red-200 text-xs font-semibold text-red-600 hover:bg-red-50"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
