import { ExternalLink, Film } from 'lucide-react';

interface VideoPreviewPlayerProps {
  videoUrl?: string;
  posterUrl?: string;
  title: string;
  className?: string;
}

function getEmbedUrl(rawUrl: string): string | null {
  try {
    const parsed = new URL(rawUrl, window.location.origin);
    const host = parsed.hostname.toLowerCase();

    if (host.includes('youtube.com')) {
      const v = parsed.searchParams.get('v');
      if (v) return `https://www.youtube.com/embed/${v}`;
      if (parsed.pathname.startsWith('/embed/')) return rawUrl;
    }
    if (host === 'youtu.be') {
      const id = parsed.pathname.slice(1);
      if (id) return `https://www.youtube.com/embed/${id}`;
    }
    if (host.includes('vimeo.com')) {
      const id = parsed.pathname.split('/').filter(Boolean).pop();
      if (id && /^\d+$/.test(id)) return `https://player.vimeo.com/video/${id}`;
    }
    return null;
  } catch {
    return null;
  }
}

function isDirectVideoFile(url: string): boolean {
  const clean = url.split('?')[0].toLowerCase();
  return clean.endsWith('.mp4') || clean.endsWith('.webm') || clean.endsWith('.mov') || url.startsWith('/uploads/');
}

export function VideoPreviewPlayer({ videoUrl, posterUrl, title, className = '' }: VideoPreviewPlayerProps) {
  if (!videoUrl) {
    return (
      <div className={`flex flex-col items-center justify-center bg-[#0B192C] text-slate-300 p-8 rounded-xl border border-slate-800 ${className}`}>
        <Film className="w-8 h-8 text-[#D9B44A] mb-2" aria-hidden="true" />
        <p className="text-sm font-medium text-white">No video trailer attached to this project</p>
      </div>
    );
  }

  if (isDirectVideoFile(videoUrl)) {
    return (
      <video
        src={videoUrl}
        poster={posterUrl || undefined}
        controls
        preload="metadata"
        className={`w-full rounded-xl bg-black aspect-video object-contain ${className}`}
      >
        Your browser does not support embedded video playback.
      </video>
    );
  }

  const embedUrl = getEmbedUrl(videoUrl);
  if (embedUrl) {
    return (
      <div className={`relative w-full aspect-video rounded-xl overflow-hidden bg-black ${className}`}>
        <iframe
          src={embedUrl}
          title={title}
          className="absolute inset-0 w-full h-full border-0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
    );
  }

  return (
    <div className={`flex flex-col items-center justify-center bg-[#0B192C] text-slate-200 p-8 rounded-xl border border-slate-800 ${className}`}>
      <Film className="w-8 h-8 text-[#D9B44A] mb-3" aria-hidden="true" />
      <p className="text-sm mb-4 text-center max-w-md">External video link provided for this promotional trailer.</p>
      <a
        href={videoUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#C59B27] text-[#0B192C] text-sm font-semibold hover:bg-[#D9B44A] transition-colors"
      >
        <span>Open Trailer Video</span>
        <ExternalLink className="w-4 h-4" aria-hidden="true" />
      </a>
    </div>
  );
}
