import { useEffect } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { PublicLayout } from './components/PublicLayout';
import { SiteDataProvider } from './context/SiteDataContext';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { FeaturedBooksPage } from './pages/FeaturedBooksPage';
import { HomePage } from './pages/HomePage';
import { PortfolioPage } from './pages/PortfolioPage';
import { ServicesPage } from './pages/ServicesPage';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminLoginPage } from './pages/admin/AdminLoginPage';
import { AdminResetPasswordPage } from './pages/admin/AdminResetPasswordPage';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <SiteDataProvider>
      <BrowserRouter>
        <ScrollToTop />
        <Routes>
          {/* Private Owner-Only Admin Routes */}
          <Route
            path="/admin/login"
            element={
              <PublicLayout>
                <AdminLoginPage />
              </PublicLayout>
            }
          />
          <Route
            path="/admin/reset-password"
            element={
              <PublicLayout>
                <AdminResetPasswordPage />
              </PublicLayout>
            }
          />
          <Route path="/admin" element={<AdminDashboardPage />} />

          {/* Public Website Routes */}
          <Route
            path="/"
            element={
              <PublicLayout>
                <HomePage />
              </PublicLayout>
            }
          />
          <Route
            path="/about"
            element={
              <PublicLayout>
                <AboutPage />
              </PublicLayout>
            }
          />
          <Route
            path="/services"
            element={
              <PublicLayout>
                <ServicesPage />
              </PublicLayout>
            }
          />
          <Route
            path="/portfolio"
            element={
              <PublicLayout>
                <PortfolioPage />
              </PublicLayout>
            }
          />
          <Route
            path="/books"
            element={
              <PublicLayout>
                <FeaturedBooksPage />
              </PublicLayout>
            }
          />
          <Route
            path="/books/:id"
            element={
              <PublicLayout>
                <FeaturedBooksPage />
              </PublicLayout>
            }
          />
          <Route
            path="/contact"
            element={
              <PublicLayout>
                <ContactPage />
              </PublicLayout>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </SiteDataProvider>
  );
}
