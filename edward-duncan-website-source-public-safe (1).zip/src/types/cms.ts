export type PortfolioCategory =
  | 'Author Spotlight Features'
  | 'Promotional Banners'
  | 'Book Trailers'
  | 'Book Covers and Graphics'
  | 'Book Marketing Campaigns'
  | 'Featured Authors'
  | 'Promotional Projects';

export const PORTFOLIO_CATEGORIES: PortfolioCategory[] = [
  'Author Spotlight Features',
  'Promotional Banners',
  'Book Trailers',
  'Book Covers and Graphics',
  'Book Marketing Campaigns',
  'Featured Authors',
  'Promotional Projects',
];

export interface ServiceItem {
  id: string;
  title: string;
  slug: string;
  shortDescription: string;
  fullDescription: string;
  deliverables: string[];
  imageUrl: string;
  featuredOnHome: boolean;
  order: number;
  active: boolean;
}

export interface PortfolioItem {
  id: string;
  projectTitle: string;
  authorName: string;
  bookTitle: string;
  bookCoverUrl: string;
  bannerImageUrl: string;
  videoUrl: string;
  videoType: 'upload' | 'external' | 'none';
  description: string;
  category: PortfolioCategory;
  publicationDate: string;
  featuredOnHome: boolean;
  createdAt: string;
}

export interface FeaturedBook {
  id: string;
  bookTitle: string;
  authorName: string;
  genre: string;
  shortDescription: string;
  promotionalNotes: string;
  bookCoverUrl: string;
  promotionalBannerUrl: string;
  trailerUrl: string;
  purchaseLink: string;
  spotlightStory: string;
  featuredOnHome: boolean;
  createdAt: string;
}

export interface AuthorProfile {
  id: string;
  fullName: string;
  penName: string;
  genres: string[];
  bio: string;
  photoUrl: string;
  website: string;
  socialLink: string;
  featuredBooksCount: number;
  createdAt: string;
}

export interface TestimonialItem {
  id: string;
  authorName: string;
  authorPhotoUrl: string;
  bookTitle: string;
  bookCoverUrl: string;
  testimonialText: string;
  authorLink: string;
  rating?: number;
  published: boolean;
  isPlaceholder: boolean;
  createdAt: string;
}

export interface IntroPillar {
  title: string;
  subtitle: string;
}

export interface HomepageContent {
  heroKicker: string;
  heroHeadline: string;
  heroSubheadline: string;
  heroImageUrl: string;
  primaryCtaLabel: string;
  secondaryCtaLabel: string;
  introKicker: string;
  introHeading: string;
  introBody: string;
  introPortraitUrl: string;
  introPillars: IntroPillar[];
  introCtaLabel: string;
  showcaseKicker: string;
  showcaseHeading: string;
  showcaseSubheading: string;
  showcaseCtaLabel: string;
  servicesKicker: string;
  servicesHeading: string;
  servicesSubheading: string;
  servicesCtaLabel: string;
  successStoriesKicker: string;
  successStoriesHeading: string;
  successStoriesSubheading: string;
  successStoriesCtaLabel: string;
  testimonialsKicker: string;
  testimonialsHeading: string;
  testimonialsSubheading: string;
  ctaKicker: string;
  ctaHeading: string;
  ctaBody: string;
  ctaButtonLabel: string;
}

export interface AboutContent {
  heroKicker: string;
  heroHeading: string;
  heroSubheading: string;
  portraitUrl: string;
  specialistName: string;
  specialistTitle: string;
  biography: string[];
  missionLabel: string;
  missionHeading: string;
  mission: string;
  visionLabel: string;
  visionHeading: string;
  vision: string;
  approachKicker: string;
  approachHeading: string;
  approachSubheading: string;
  marketingApproach: { title: string; description: string }[];
  commitmentKicker: string;
  whyHeading: string;
  commitmentStatement: string;
  whyWorkWithUs: { title: string; description: string }[];
  primaryCtaLabel: string;
  secondaryCtaLabel: string;
}

export interface PagesCopyContent {
  // Navigation & Global Header/Footer
  navHomeLabel: string;
  navAboutLabel: string;
  navServicesLabel: string;
  navPortfolioLabel: string;
  navBooksLabel: string;
  navContactLabel: string;
  navAdminLabel: string;
  headerCtaLabel: string;
  footerInquiriesLabel: string;
  footerNavHeading: string;
  footerConnectHeading: string;
  footerCtaLabel: string;

  // Shared Card & Action Labels
  requestServiceLabel: string;
  inspectCampaignLabel: string;
  videoPreviewLabel: string;
  viewFeatureLabel: string;
  bookLinkLabel: string;
  authorWebsiteLabel: string;
  authorSocialLabel: string;
  emptyTestimonialsText: string;
  modalRequestCampaignLabel: string;

  // Services Page
  servicesKicker: string;
  servicesHeading: string;
  servicesSubheading: string;
  serviceNumberPrefix: string;
  deliverablesHeading: string;
  servicesBottomHeading: string;
  servicesBottomBody: string;
  servicesBottomCta: string;

  // Portfolio Page
  portfolioKicker: string;
  portfolioHeading: string;
  portfolioSubheading: string;
  portfolioAllFilterLabel: string;
  portfolioWatchTrailerLabel: string;
  portfolioViewDetailsLabel: string;
  portfolioInquireLabel: string;
  portfolioModalBookLabel: string;
  portfolioModalCtaLabel: string;

  // Featured Books & Authors Page
  booksKicker: string;
  booksHeading: string;
  booksSubheading: string;
  bookStoreShortLabel: string;
  authorsKicker: string;
  authorsHeading: string;
  backToBooksLabel: string;
  bookAboutHeading: string;
  bookSpotlightHeading: string;
  bookPromoScopeLabel: string;
  bookPurchaseLabel: string;
  bookPromoteCtaLabel: string;
  bookBannerHeading: string;
  bookTrailerHeading: string;

  // Contact Page
  contactKicker: string;
  contactHeading: string;
  contactSubheading: string;
  contactFormHeading: string;
  contactNameLabel: string;
  contactEmailLabel: string;
  contactBookTitleLabel: string;
  contactGenreLabel: string;
  contactWebsiteLabel: string;
  contactServiceLabel: string;
  contactExtraServiceOption: string;
  contactMessageLabel: string;
  contactUploadLabel: string;
  contactUploadHint: string;
  contactSubmitLabel: string;
  contactSuccessTitle: string;
  contactSidebarKicker: string;
  contactSidebarEmailLabel: string;
  contactSidebarLocationLabel: string;
  contactSidebarChannelsLabel: string;
}

export interface WebsiteSettings {
  businessName: string;
  specialistName: string;
  specialistTitle: string;
  businessDescription: string;
  contactEmail: string;
  location: string;
  socialLinks: {
    linkedin: string;
    instagram: string;
    x: string;
    facebook: string;
    youtube: string;
  };
  footerNote: string;
  seoTitle: string;
  seoDescription: string;
}

export type SubmissionStatus = 'New' | 'Reviewed' | 'Replied' | 'Archived';

export interface ContactSubmission {
  id: string;
  fullName: string;
  email: string;
  bookTitle: string;
  bookGenre: string;
  authorWebsite: string;
  requestedService: string;
  message: string;
  bookCoverUploadUrl: string;
  status: SubmissionStatus;
  adminNotes: string;
  createdAt: string;
}

export type MediaAssetType = 'author_photo' | 'book_cover' | 'banner' | 'video_trailer' | 'general';

export interface MediaAsset {
  id: string;
  filename: string;
  originalName: string;
  url: string;
  mimeType: string;
  sizeBytes: number;
  assetType: MediaAssetType;
  title: string;
  createdAt: string;
}

export interface PublicSiteData {
  settings: WebsiteSettings;
  homepage: HomepageContent;
  about: AboutContent;
  pagesCopy: PagesCopyContent;
  services: ServiceItem[];
  portfolio: PortfolioItem[];
  featuredBooks: FeaturedBook[];
  authors: AuthorProfile[];
  testimonials: TestimonialItem[];
}
