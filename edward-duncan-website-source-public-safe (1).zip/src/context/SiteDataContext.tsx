import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { PublicSiteData } from '../types/cms';

interface SiteDataContextValue {
  siteData: PublicSiteData | null;
  loading: boolean;
  error: string | null;
  refreshSiteData: () => Promise<void>;
}

const SiteDataContext = createContext<SiteDataContextValue>({
  siteData: null,
  loading: true,
  error: null,
  refreshSiteData: async () => {},
});

export function SiteDataProvider({ children }: { children: React.ReactNode }) {
  const [siteData, setSiteData] = useState<PublicSiteData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const refreshSiteData = useCallback(async () => {
    try {
      setError(null);
      const res = await fetch('/api/site', { credentials: 'include' });
      if (!res.ok) {
        throw new Error('Unable to load agency content.');
      }
      const data = (await res.json()) as PublicSiteData;
      setSiteData(data);
      if (data.settings?.seoTitle) {
        document.title = data.settings.seoTitle;
      }
      if (data.settings?.seoDescription) {
        const metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) {
          metaDesc.setAttribute('content', data.settings.seoDescription);
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load site data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshSiteData();
  }, [refreshSiteData]);

  return (
    <SiteDataContext.Provider value={{ siteData, loading, error, refreshSiteData }}>
      {children}
    </SiteDataContext.Provider>
  );
}

export function useSiteData(): SiteDataContextValue {
  return useContext(SiteDataContext);
}
