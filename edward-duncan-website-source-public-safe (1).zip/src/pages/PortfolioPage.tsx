import { ArrowRight, Play, X } from 'lucide-react';
import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ResilientImage } from '../components/ResilientImage';
import { VideoPreviewPlayer } from '../components/VideoPreviewPlayer';
import { useSiteData } from '../context/SiteDataContext';
import { PORTFOLIO_CATEGORIES } from '../types/cms';
import type { PortfolioCategory, PortfolioItem } from '../types/cms';

export function PortfolioPage() {
  const { siteData, loading } = useSiteData();
  const [activeCategory, setActiveCategory] = useState<'All' | PortfolioCategory>('All');
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);

  const items = useMemo(() => {
    if (!siteData) return [];
    if (activeCategory === 'All') return siteData.portfolio;
    return siteData.portfolio.filter((p) => p.category === activeCategory);
  }, [siteData, activeCategory]);

  if (loading && !siteData) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 animate-pulse space-y-8">
        <div className="h-40 bg-slate-100 rounded-xl" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="h-72 bg-slate-100 rounded-xl" />
          <div className="h-72 bg-slate-100 rounded-xl" />
          <div className="h-72 bg-slate-100 rounded-xl" />
        </div>
      </div>
    );
  }

  const pagesCopy = siteData?.pagesCopy;

  return (
    <div>
      {/* Header */}
      <section className="bg-[#0B192C] text-white py-20 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <p className="text-xs font-semibold tracking-wide text-[#D9B44A]">
              {pagesCopy?.portfolioKicker || 'Promotional Portfolio'}
            </p>
            <h1
              className="font-display font-semibold tracking-tight text-white text-balance leading-tight"
              style={{ fontSize: 'clamp(2rem, 3.8vw, 3.25rem)' }}
            >
              {pagesCopy?.portfolioHeading || 'Featured Work, Banners & Cinematic Book Trailers'}
            </h1>
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
              {pagesCopy?.portfolioSubheading ||
                'Explore promotional campaigns, custom author spotlight banners, book trailer productions, and book presentation work managed by Edward Duncan Book Promotions.'}
            </p>
          </div>
        </div>
      </section>

      {/* Filter Bar & Gallery */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          {/* Interactive Category Filter Buttons */}
          <div className="flex flex-wrap items-center gap-2 p-1.5 bg-[#F8F9FB] border border-slate-200 rounded-xl">
            <button
              type="button"
              onClick={() => setActiveCategory('All')}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                activeCategory === 'All'
                  ? 'bg-[#0B192C] text-white'
                  : 'text-slate-600 hover:text-[#0B192C] hover:bg-white'
              }`}
            >
              {pagesCopy?.portfolioAllFilterLabel || 'All Work'}
            </button>
            {PORTFOLIO_CATEGORIES.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setActiveCategory(category)}
                className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  activeCategory === category
                    ? 'bg-[#0B192C] text-white'
                    : 'text-slate-600 hover:text-[#0B192C] hover:bg-white'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {items.length === 0 ? (
            <div className="border border-slate-200 rounded-xl p-12 text-center space-y-3 bg-[#F8F9FB]">
              <p className="font-display text-xl font-semibold text-[#0B192C]">
                No Projects in “{activeCategory}” Yet
              </p>
              <p className="text-sm text-slate-600 max-w-md mx-auto">
                Projects uploaded to this category from the agency Admin Dashboard will appear here automatically.
              </p>
              <button
                type="button"
                onClick={() => setActiveCategory('All')}
                className="px-4 py-2 rounded-lg bg-[#0B192C] text-white text-xs font-semibold"
              >
                View All Categories
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {items.map((item) => (
                <article
                  key={item.id}
                  className="group border border-slate-200 rounded-xl overflow-hidden bg-white flex flex-col justify-between"
                >
                  <button
                    type="button"
                    onClick={() => setSelectedItem(item)}
                    className="relative w-full aspect-[16/10] bg-slate-900 overflow-hidden text-left"
                  >
                    <ResilientImage
                      src={item.bannerImageUrl || item.bookCoverUrl}
                      alt={item.projectTitle}
                      fallbackTitle={item.bookTitle || item.projectTitle}
                      className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                    />
                    {item.videoUrl && (
                      <span className="absolute bottom-3 right-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#0B192C]/90 text-white text-xs font-medium">
                        <Play className="w-3.5 h-3.5 text-[#D9B44A]" aria-hidden="true" />
                        <span>{pagesCopy?.portfolioWatchTrailerLabel || 'Watch Trailer'}</span>
                      </span>
                    )}
                  </button>

                  <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <p className="text-xs text-slate-500">
                        <span className="font-medium text-[#8F6A10]">{item.category}</span>
                        <span aria-hidden="true"> · </span>
                        <span className="font-mono-tabular">{item.publicationDate}</span>
                      </p>
                      <h2 className="font-display text-xl font-semibold text-[#0B192C]">
                        {item.projectTitle}
                      </h2>
                      <p className="text-xs font-medium text-slate-600">
                        {item.bookTitle}
                        {item.authorName ? ` · ${item.authorName}` : ''}
                      </p>
                      <p className="text-sm text-slate-600 leading-relaxed line-clamp-3">
                        {item.description}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setSelectedItem(item)}
                        className="text-xs font-semibold text-[#0B192C] hover:text-[#8F6A10] transition-colors"
                      >
                        {pagesCopy?.portfolioViewDetailsLabel || 'View Project Details'}
                      </button>
                      <Link
                        to={`/contact?service=${encodeURIComponent(item.category)}`}
                        className="text-xs font-medium text-slate-500 hover:text-[#0B192C]"
                      >
                        {pagesCopy?.portfolioInquireLabel || 'Inquire'}
                      </Link>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Lightbox Modal */}
      {selectedItem && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={selectedItem.projectTitle}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          onClick={() => setSelectedItem(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-4xl w-full overflow-hidden border border-slate-200 shadow-2xl my-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <div>
                <p className="text-xs text-[#8F6A10] font-medium">
                  {selectedItem.category} · {selectedItem.publicationDate}
                </p>
                <h3 className="font-display text-xl font-semibold text-[#0B192C]">
                  {selectedItem.projectTitle}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedItem(null)}
                aria-label="Close project preview"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
              {selectedItem.videoUrl ? (
                <VideoPreviewPlayer
                  videoUrl={selectedItem.videoUrl}
                  posterUrl={selectedItem.bannerImageUrl || selectedItem.bookCoverUrl}
                  title={selectedItem.projectTitle}
                />
              ) : selectedItem.bannerImageUrl ? (
                <div className="rounded-xl overflow-hidden border border-slate-200 aspect-[16/9] bg-slate-100">
                  <ResilientImage
                    src={selectedItem.bannerImageUrl}
                    alt={`${selectedItem.projectTitle} promotional banner`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : null}

              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                {selectedItem.bookCoverUrl && (
                  <div className="md:col-span-4 rounded-xl overflow-hidden border border-slate-200 aspect-[3/4]">
                    <ResilientImage
                      src={selectedItem.bookCoverUrl}
                      alt={selectedItem.bookTitle}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div className={selectedItem.bookCoverUrl ? 'md:col-span-8 space-y-4' : 'md:col-span-12 space-y-4'}>
                  <div className="space-y-1">
                    <p className="text-xs text-slate-500">
                      {pagesCopy?.portfolioModalBookLabel || 'Featured Book & Author'}
                    </p>
                    <p className="text-base font-semibold text-[#0B192C]">
                      {selectedItem.bookTitle}
                      {selectedItem.authorName ? ` — ${selectedItem.authorName}` : ''}
                    </p>
                  </div>
                  <p className="text-slate-700 leading-relaxed">{selectedItem.description}</p>
                  <div className="pt-2">
                    <Link
                      to={`/contact?service=${encodeURIComponent(selectedItem.category)}`}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945]"
                    >
                      <span>{pagesCopy?.portfolioModalCtaLabel || 'Request This Campaign Style'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
