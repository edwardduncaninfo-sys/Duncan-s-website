import { ArrowRight, Check } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ResilientImage } from '../components/ResilientImage';
import { useSiteData } from '../context/SiteDataContext';

export function ServicesPage() {
  const { siteData, loading } = useSiteData();

  if (loading && !siteData) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 animate-pulse space-y-8">
        <div className="h-40 bg-slate-100 rounded-xl" />
        <div className="h-64 bg-slate-100 rounded-xl" />
        <div className="h-64 bg-slate-100 rounded-xl" />
      </div>
    );
  }

  if (!siteData) return null;
  const { services, pagesCopy } = siteData;

  return (
    <div>
      {/* Header */}
      <section className="bg-[#0B192C] text-white py-20 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <p className="text-xs font-semibold tracking-wide text-[#D9B44A]">
              {pagesCopy.servicesKicker}
            </p>
            <h1
              className="font-display font-semibold tracking-tight text-white text-balance leading-tight"
              style={{ fontSize: 'clamp(2rem, 3.8vw, 3.25rem)' }}
            >
              {pagesCopy.servicesHeading}
            </h1>
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
              {pagesCopy.servicesSubheading}
            </p>
          </div>
        </div>
      </section>

      {/* Services List */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          {services.map((service, idx) => {
            const reversed = idx % 2 === 1;
            return (
              <article
                key={service.id}
                id={service.slug}
                className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch pb-16 border-b border-slate-200 last:border-b-0 last:pb-0"
              >
                <div className={`lg:col-span-5 ${reversed ? 'lg:order-2' : ''}`}>
                  <div className="h-full min-h-[280px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                    <ResilientImage
                      src={service.imageUrl}
                      alt={service.title}
                      fallbackTitle={service.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                <div className={`lg:col-span-7 flex flex-col justify-center space-y-5 ${reversed ? 'lg:order-1' : ''}`}>
                  <div className="space-y-2">
                    <p className="text-xs font-mono-tabular text-[#8F6A10] font-semibold">
                      {pagesCopy.serviceNumberPrefix} {String(idx + 1).padStart(2, '0')}
                    </p>
                    <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#0B192C]">
                      {service.title}
                    </h2>
                  </div>

                  <p className="text-slate-600 leading-relaxed text-base">
                    {service.fullDescription || service.shortDescription}
                  </p>

                  {service.deliverables.length > 0 && (
                    <div className="space-y-2 pt-2">
                      <p className="text-xs font-semibold tracking-wide text-slate-500">
                        {pagesCopy.deliverablesHeading}
                      </p>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {service.deliverables.map((item, dIdx) => (
                          <li key={dIdx} className="flex items-start gap-2 text-sm text-slate-700">
                            <Check className="w-4 h-4 text-[#C59B27] shrink-0 mt-0.5" aria-hidden="true" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="pt-3">
                    <Link
                      to={`/contact?service=${encodeURIComponent(service.title)}`}
                      className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] transition-colors"
                    >
                      <span>{pagesCopy.requestServiceLabel}</span>
                      <ArrowRight className="w-4 h-4" aria-hidden="true" />
                    </Link>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="py-16 bg-[#F8F9FB] border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#0B192C]">
              {pagesCopy.servicesBottomHeading}
            </h2>
            <p className="text-slate-600 text-sm sm:text-base">
              {pagesCopy.servicesBottomBody}
            </p>
          </div>
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-[#C59B27] text-[#0B192C] text-sm font-semibold hover:bg-[#D9B44A] transition-colors whitespace-nowrap shrink-0"
          >
            <span>{pagesCopy.servicesBottomCta}</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </Link>
        </div>
      </section>
    </div>
  );
}
