import { AlertCircle, ArrowLeft, Eye, EyeOff, Lock } from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { adminFetch, setAdminToken } from '../../utils/adminAuth';

export function AdminLoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [checkingSession, setCheckingSession] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    adminFetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        if (mounted && data?.authenticated) {
          navigate('/admin', { replace: true });
        }
      })
      .catch(() => {})
      .finally(() => {
        if (mounted) setCheckingSession(false);
      });
    return () => {
      mounted = false;
    };
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!email.trim() || !password) {
      setErrorMsg('Please enter both your owner email address and password.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email: email.trim(), password }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed.');
      }
      if (data.sessionToken) {
        setAdminToken(data.sessionToken);
      }
      navigate('/admin', { replace: true });
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to sign in.');
    } finally {
      setSubmitting(false);
    }
  };

  if (checkingSession) {
    return (
      <div className="bg-[#06101E] py-28 flex items-center justify-center p-4">
        <div className="text-sm text-slate-300">Verifying owner session...</div>
      </div>
    );
  }

  return (
    <div className="bg-[#06101E] flex flex-col justify-center py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full mx-auto space-y-8">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-[#11223B] border border-slate-700 text-[#D9B44A] mb-2">
            <Lock className="w-5 h-5" aria-hidden="true" />
          </div>
          <h1 className="font-display text-3xl font-semibold text-white">
            Owner Administration
          </h1>
          <p className="text-sm text-slate-400">
            Edward Duncan Book Promotions · Private Agency Console
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-xl space-y-6">
          {errorMsg && (
            <div
              role="alert"
              className="flex items-start gap-2.5 p-3.5 rounded-lg border border-red-200 bg-red-50 text-red-900 text-sm"
            >
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="owner-email" className="block text-sm font-medium text-slate-800 mb-1.5">
                Owner Email Address
              </label>
              <input
                id="owner-email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="owner@domain.com"
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#C59B27]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="owner-password" className="block text-sm font-medium text-slate-800">
                  Password
                </label>
                <Link
                  to="/admin/reset-password"
                  className="text-xs font-medium text-[#8F6A10] hover:underline"
                >
                  Reset Password
                </Link>
              </div>
              <div className="relative">
                <input
                  id="owner-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter owner password"
                  className="w-full px-4 py-2.5 pr-11 rounded-lg border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#C59B27]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute inset-y-0 right-0 px-3 flex items-center text-slate-500 hover:text-slate-800"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] disabled:opacity-60 transition-colors"
            >
              {submitting ? 'Signing In...' : 'Sign In to Dashboard'}
            </button>
          </form>

          <p className="text-xs text-slate-500 text-center pt-2 border-t border-slate-100">
            Access is strictly restricted to the authorized website owner. Public account creation is disabled.
          </p>
        </div>

        <div className="text-center">
          <Link
            to="/"
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Public Website</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
