import { ArrowLeft, ArrowRight, ExternalLink } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import { ResilientImage } from '../components/ResilientImage';
import { VideoPreviewPlayer } from '../components/VideoPreviewPlayer';
import { useSiteData } from '../context/SiteDataContext';

export function FeaturedBooksPage() {
  const { id } = useParams<{ id?: string }>();
  const { siteData, loading } = useSiteData();

  if (loading && !siteData) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 animate-pulse space-y-8">
        <div className="h-40 bg-slate-100 rounded-xl" />
        <div className="h-80 bg-slate-100 rounded-xl" />
      </div>
    );
  }

  if (!siteData) return null;
  const { featuredBooks, authors, pagesCopy } = siteData;

  if (id) {
    const book = featuredBooks.find((b) => b.id === id);
    if (!book) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center space-y-4">
          <h1 className="font-display text-3xl font-semibold text-[#0B192C]">
            Featured Book Not Found
          </h1>
          <p className="text-slate-600">
            The requested promotional feature could not be located.
          </p>
          <Link
            to="/books"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#0B192C] text-white text-sm font-semibold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Featured Books</span>
          </Link>
        </div>
      );
    }

    return (
      <div>
        <section className="bg-[#0B192C] text-white py-16 border-b border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
            <Link
              to="/books"
              className="inline-flex items-center gap-2 text-xs font-semibold text-[#D9B44A] hover:text-white transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{pagesCopy.backToBooksLabel}</span>
            </Link>
            <p className="text-xs text-slate-300">
              {book.genre} · {book.authorName}
            </p>
            <h1
              className="font-display font-semibold text-white tracking-tight text-balance"
              style={{ fontSize: 'clamp(2rem, 3.6vw, 3rem)' }}
            >
              {book.bookTitle}
            </h1>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-14">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
              <div className="lg:col-span-4">
                <div className="rounded-xl overflow-hidden border border-slate-200 aspect-[3/4] bg-slate-100">
                  <ResilientImage
                    src={book.bookCoverUrl}
                    alt={`${book.bookTitle} cover`}
                    fallbackTitle={book.bookTitle}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>

              <div className="lg:col-span-8 space-y-6">
                <div className="space-y-3">
                  <h2 className="font-display text-2xl font-semibold text-[#0B192C]">
                    {pagesCopy.bookAboutHeading}
                  </h2>
                  <p className="text-slate-700 leading-relaxed text-base">{book.shortDescription}</p>
                </div>

                {book.spotlightStory && (
                  <div className="space-y-2 pt-4 border-t border-slate-200">
                    <h3 className="font-display text-xl font-semibold text-[#0B192C]">
                      {pagesCopy.bookSpotlightHeading}
                    </h3>
                    <p className="text-slate-600 leading-relaxed">{book.spotlightStory}</p>
                  </div>
                )}

                {book.promotionalNotes && (
                  <div className="bg-[#F8F9FB] border border-slate-200 rounded-xl p-6 space-y-2">
                    <p className="text-xs font-semibold text-[#8F6A10] tracking-wide">
                      {pagesCopy.bookPromoScopeLabel}
                    </p>
                    <p className="text-sm text-slate-700 leading-relaxed">{book.promotionalNotes}</p>
                  </div>
                )}

                <div className="pt-2 flex flex-wrap items-center gap-4">
                  {book.purchaseLink && (
                    <a
                      href={book.purchaseLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-[#C59B27] text-[#0B192C] text-sm font-semibold hover:bg-[#D9B44A] transition-colors"
                    >
                      <span>{pagesCopy.bookPurchaseLabel}</span>
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                  <Link
                    to="/contact"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-[#0B192C] text-white text-sm font-semibold hover:bg-[#132945] transition-colors"
                  >
                    <span>{pagesCopy.bookPromoteCtaLabel}</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </div>

            {book.promotionalBannerUrl && (
              <div className="space-y-4">
                <h3 className="font-display text-2xl font-semibold text-[#0B192C]">
                  {pagesCopy.bookBannerHeading}
                </h3>
                <div className="rounded-xl overflow-hidden border border-slate-200 aspect-[16/9] max-h-[520px] bg-slate-100">
                  <ResilientImage
                    src={book.promotionalBannerUrl}
                    alt={`${book.bookTitle} promotional banner`}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}

            {book.trailerUrl && (
              <div className="space-y-4">
                <h3 className="font-display text-2xl font-semibold text-[#0B192C]">
                  {pagesCopy.bookTrailerHeading}
                </h3>
                <VideoPreviewPlayer
                  videoUrl={book.trailerUrl}
                  posterUrl={book.promotionalBannerUrl || book.bookCoverUrl}
                  title={`${book.bookTitle} Trailer`}
                />
              </div>
            )}
          </div>
        </section>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <section className="bg-[#0B192C] text-white py-20 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <p className="text-xs font-semibold tracking-wide text-[#D9B44A]">
              {pagesCopy.booksKicker}
            </p>
            <h1
              className="font-display font-semibold tracking-tight text-white text-balance leading-tight"
              style={{ fontSize: 'clamp(2rem, 3.8vw, 3.25rem)' }}
            >
              {pagesCopy.booksHeading}
            </h1>
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
              {pagesCopy.booksSubheading}
            </p>
          </div>
        </div>
      </section>

      {/* Books Grid */}
      <section className="py-20 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredBooks.map((book) => (
              <article
                key={book.id}
                className="border border-slate-200 rounded-xl overflow-hidden bg-white flex flex-col justify-between"
              >
                <Link
                  to={`/books/${book.id}`}
                  className="block aspect-[4/3] bg-slate-100 overflow-hidden"
                >
                  <ResilientImage
                    src={book.bookCoverUrl}
                    alt={book.bookTitle}
                    fallbackTitle={book.bookTitle}
                    className="w-full h-full object-cover hover:scale-[1.02] transition-transform duration-300"
                  />
                </Link>
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <p className="text-xs text-slate-500">
                      <span className="font-medium text-[#8F6A10]">{book.genre}</span>
                      <span aria-hidden="true"> · </span>
                      <span>{book.authorName}</span>
                    </p>
                    <h2 className="font-display text-xl font-semibold text-[#0B192C]">
                      <Link to={`/books/${book.id}`} className="hover:text-[#8F6A10] transition-colors">
                        {book.bookTitle}
                      </Link>
                    </h2>
                    <p className="text-sm text-slate-600 leading-relaxed line-clamp-3">
                      {book.shortDescription}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                    <Link
                      to={`/books/${book.id}`}
                      className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#0B192C] hover:text-[#8F6A10]"
                    >
                      <span>{pagesCopy.viewFeatureLabel}</span>
                      <ArrowRight className="w-4 h-4" />
                    </Link>
                    {book.purchaseLink && (
                      <a
                        href={book.purchaseLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-[#0B192C]"
                      >
                        <span>{pagesCopy.bookStoreShortLabel}</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Authors Directory */}
      {authors.length > 0 && (
        <section className="py-20 bg-[#F8F9FB]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
            <div className="max-w-2xl space-y-2">
              <p className="text-xs font-semibold tracking-wide text-[#8F6A10]">
                {pagesCopy.authorsKicker}
              </p>
              <h2 className="font-display text-3xl font-semibold text-[#0B192C]">
                {pagesCopy.authorsHeading}
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {authors.map((author) => (
                <article
                  key={author.id}
                  className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-xl overflow-hidden border border-slate-200 shrink-0 bg-slate-100">
                      <ResilientImage
                        src={author.photoUrl}
                        alt={author.fullName}
                        fallbackTitle={author.fullName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-display text-lg font-semibold text-[#0B192C] truncate">
                        {author.fullName}
                      </h3>
                      {author.genres.length > 0 && (
                        <p className="text-xs text-[#8F6A10] truncate">
                          {author.genres.join(' · ')}
                        </p>
                      )}
                    </div>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">{author.bio}</p>
                  {(author.website || author.socialLink) && (
                    <div className="pt-2 flex items-center gap-4 text-xs font-semibold text-[#0B192C]">
                      {author.website && (
                        <a
                          href={author.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 hover:text-[#8F6A10]"
                        >
                          <span>{pagesCopy.authorWebsiteLabel}</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                      {author.socialLink && (
                        <a
                          href={author.socialLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 hover:text-[#8F6A10]"
                        >
                          <span>{pagesCopy.authorSocialLabel}</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>
                  )}
                </article>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
