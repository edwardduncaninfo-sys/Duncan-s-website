import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ResilientImage } from '../components/ResilientImage';
import { useSiteData } from '../context/SiteDataContext';

export function AboutPage() {
  const { siteData, loading } = useSiteData();

  if (loading && !siteData) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 animate-pulse space-y-8">
        <div className="h-40 bg-slate-100 rounded-xl" />
        <div className="h-96 bg-slate-100 rounded-xl" />
      </div>
    );
  }

  if (!siteData) return null;
  const { about } = siteData;

  return (
    <div>
      {/* Page Header */}
      <section className="bg-[#0B192C] text-white py-20 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <p className="text-xs font-semibold tracking-wide text-[#D9B44A]">
              {about.heroKicker}
            </p>
            <h1
              className="font-display font-semibold tracking-tight text-white text-balance leading-tight"
              style={{ fontSize: 'clamp(2rem, 3.8vw, 3.25rem)' }}
            >
              {about.heroHeading}
            </h1>
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
              {about.heroSubheading}
            </p>
          </div>
        </div>
      </section>

      {/* Biography Split */}
      <section className="py-20 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
            <div className="lg:col-span-5">
              <div className="h-full min-h-[420px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                <ResilientImage
                  src={about.portraitUrl}
                  alt={`${about.specialistName} — ${about.specialistTitle}`}
                  fallbackTitle={about.specialistName}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              <div>
                <h2 className="font-display text-3xl font-semibold text-[#0B192C]">
                  {about.specialistName}
                </h2>
                <p className="text-sm font-medium text-[#8F6A10] mt-1">{about.specialistTitle}</p>
              </div>
              <div className="space-y-4 text-slate-600 leading-relaxed text-base">
                {about.biography.map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-[#F8F9FB] border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white border border-slate-200 rounded-xl p-8 space-y-3">
              <p className="text-xs font-semibold tracking-wide text-[#8F6A10]">{about.missionLabel}</p>
              <h3 className="font-display text-2xl font-semibold text-[#0B192C]">
                {about.missionHeading}
              </h3>
              <p className="text-slate-600 leading-relaxed">{about.mission}</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-8 space-y-3">
              <p className="text-xs font-semibold tracking-wide text-[#8F6A10]">{about.visionLabel}</p>
              <h3 className="font-display text-2xl font-semibold text-[#0B192C]">
                {about.visionHeading}
              </h3>
              <p className="text-slate-600 leading-relaxed">{about.vision}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Approach to Book Marketing */}
      <section className="py-20 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl space-y-3 mb-12">
            <p className="text-xs font-semibold tracking-wide text-[#8F6A10]">{about.approachKicker}</p>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-[#0B192C] tracking-tight">
              {about.approachHeading}
            </h2>
            <p className="text-slate-600 leading-relaxed">
              {about.approachSubheading}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {about.marketingApproach.map((step, i) => (
              <div
                key={i}
                className="border border-slate-200 rounded-xl p-7 bg-white space-y-2.5"
              >
                <h3 className="font-display text-xl font-semibold text-[#0B192C]">{step.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Commitment & Why Work With Us */}
      <section className="py-20 bg-[#0B192C] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-14">
          <div className="max-w-3xl space-y-4">
            <p className="text-xs font-semibold tracking-wide text-[#D9B44A]">
              {about.commitmentKicker}
            </p>
            <h2 className="font-display text-3xl font-semibold text-white text-balance">
              {about.whyHeading}
            </h2>
            <p className="text-slate-300 leading-relaxed text-base">{about.commitmentStatement}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {about.whyWorkWithUs.map((reason, idx) => (
              <div
                key={idx}
                className="bg-[#11223B] border border-slate-700/70 rounded-xl p-6 space-y-2.5"
              >
                <h3 className="font-display text-lg font-semibold text-white">{reason.title}</h3>
                <p className="text-sm text-slate-300 leading-relaxed">{reason.description}</p>
              </div>
            ))}
          </div>

          <div className="pt-4 flex flex-wrap gap-4">
            <Link
              to="/services"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-[#C59B27] text-[#0B192C] text-sm font-semibold hover:bg-[#D9B44A] transition-colors"
            >
              <span>{about.primaryCtaLabel}</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </Link>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg border border-white/30 text-white text-sm font-semibold hover:bg-white/10 transition-colors"
            >
              <span>{about.secondaryCtaLabel}</span>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
