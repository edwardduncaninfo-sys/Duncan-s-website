import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import cookieParser from 'cookie-parser';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import multer from 'multer';
import {
  generateRecoveryKey,
  generateResetCode,
  generateSessionToken,
  hashPassword,
  hashToken,
  signSessionValue,
  verifyPassword,
  verifySignedSessionValue,
} from './server/auth.ts';
import { getPublicSiteData, loadDatabase, saveDatabase } from './server/db.ts';
import type {
  AuthorProfile,
  ContactSubmission,
  FeaturedBook,
  MediaAsset,
  MediaAssetType,
  PortfolioCategory,
  PortfolioItem,
  ServiceItem,
  SubmissionStatus,
  TestimonialItem,
} from './src/types/cms.ts';

const PORT = Number(process.env.PORT || 3000);
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
const SESSION_COOKIE = 'edbp_owner_session';
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const RESET_TTL_MS = 15 * 60 * 1000;

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Initialize database on startup
loadDatabase();

// Simple in-memory rate limiting for login attempts
const loginAttempts = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = loginAttempts.get(ip);
  if (!entry || entry.resetAt < now) {
    loginAttempts.set(ip, { count: 1, resetAt: now + 15 * 60 * 1000 });
    return true;
  }
  if (entry.count >= 10) {
    return false;
  }
  entry.count += 1;
  return true;
}

function getCookieOptions(req: Request, maxAge?: number) {
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
  return {
    httpOnly: true,
    sameSite: (isHttps ? 'none' : 'lax') as 'none' | 'lax',
    secure: isHttps,
    path: '/',
    ...(typeof maxAge === 'number' ? { maxAge } : {}),
  };
}

function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

const ALLOWED_IMAGE_MIMES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/gif',
]);

const ALLOWED_MEDIA_MIMES = new Set([
  ...ALLOWED_IMAGE_MIMES,
  'video/mp4',
  'video/webm',
  'video/quicktime',
]);

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().replace(/[^a-z0-9.]/g, '') || '.bin';
    const base = path.basename(file.originalname, path.extname(file.originalname))
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .slice(0, 32) || 'asset';
    const unique = crypto.randomBytes(6).toString('hex');
    cb(null, `${Date.now()}-${base}-${unique}${ext}`);
  },
});

const adminUpload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (ALLOWED_MEDIA_MIMES.has(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Unsupported file format. Please upload JPG, PNG, WebP, GIF, MP4, WebM, or MOV files.'));
    }
  },
});

const publicCoverUpload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (ALLOWED_IMAGE_MIMES.has(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Book cover must be an image file (JPG, PNG, WebP, or GIF).'));
    }
  },
});

interface AuthenticatedRequest extends Request {
  adminSessionId?: string;
}

function extractSignedTokenFromRequest(req: Request): string | undefined {
  const cookieToken = req.cookies?.[SESSION_COOKIE] as string | undefined;
  if (cookieToken) {
    return cookieToken;
  }
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  return undefined;
}

function getAuthenticatedSession(req: Request): { sessionId: string; email: string } | null {
  const db = loadDatabase();
  const rawCookie = extractSignedTokenFromRequest(req);
  const token = verifySignedSessionValue(rawCookie, db.sessionSecret);
  if (!token) {
    return null;
  }
  const tokenHash = hashToken(token);
  const now = Date.now();
  const activeSessions = db.sessions.filter((s) => new Date(s.expiresAt).getTime() > now);
  if (activeSessions.length !== db.sessions.length) {
    db.sessions = activeSessions;
    saveDatabase(db);
  }
  const match = db.sessions.find((s) => s.tokenHash === tokenHash);
  if (!match) {
    return null;
  }
  return { sessionId: match.id, email: db.owner.email };
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const session = getAuthenticatedSession(req);
  if (!session) {
    res.status(401).json({ error: 'Authentication required. Owner access only.' });
    return;
  }
  req.adminSessionId = session.sessionId;
  next();
}

async function startServer(): Promise<void> {
  const app = express();
  app.set('trust proxy', 1);

  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.use(cookieParser());
  app.use(express.json({ limit: '5mb' }));

  // Serve uploaded images & videos safely
  app.use(
    '/uploads',
    express.static(UPLOADS_DIR, {
      setHeaders: (res) => {
        res.setHeader('X-Content-Type-Options', 'nosniff');
      },
    }),
  );

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  // Public Site Data
  app.get('/api/site', (_req, res) => {
    const db = loadDatabase();
    res.json(getPublicSiteData(db));
  });

  app.get('/api/books/:id', (req, res) => {
    const db = loadDatabase();
    const book = db.featuredBooks.find((b) => b.id === req.params.id);
    if (!book) {
      res.status(404).json({ error: 'Featured book not found.' });
      return;
    }
    res.json({ book });
  });

  // Public Contact Form Submission (with optional book cover upload)
  app.post('/api/contact', (req, res) => {
    publicCoverUpload.single('bookCover')(req, res, (err) => {
      if (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'File upload failed.' });
        return;
      }

      const fullName = String(req.body.fullName || '').trim();
      const email = String(req.body.email || '').trim();
      const bookTitle = String(req.body.bookTitle || '').trim();
      const bookGenre = String(req.body.bookGenre || '').trim();
      const authorWebsite = String(req.body.authorWebsite || '').trim();
      const requestedService = String(req.body.requestedService || '').trim();
      const message = String(req.body.message || '').trim();

      if (!fullName || !email || !bookTitle || !requestedService || !message) {
        res.status(400).json({
          error: 'Please complete all required fields: Full Name, Email Address, Book Title, Requested Service, and Message.',
        });
        return;
      }

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        res.status(400).json({ error: 'Please provide a valid email address.' });
        return;
      }

      const db = loadDatabase();
      let bookCoverUploadUrl = '';
      const now = new Date().toISOString();

      if (req.file) {
        bookCoverUploadUrl = `/uploads/${req.file.filename}`;
        db.mediaLibrary.unshift({
          id: `media-${crypto.randomUUID()}`,
          filename: req.file.filename,
          originalName: req.file.originalname,
          url: bookCoverUploadUrl,
          mimeType: req.file.mimetype,
          sizeBytes: req.file.size,
          assetType: 'book_cover',
          title: `Inquiry Cover: ${bookTitle}`,
          createdAt: now,
        });
      }

      const submission: ContactSubmission = {
        id: `sub-${crypto.randomUUID()}`,
        fullName,
        email,
        bookTitle,
        bookGenre: bookGenre || 'Unspecified',
        authorWebsite,
        requestedService,
        message,
        bookCoverUploadUrl,
        status: 'New',
        adminNotes: '',
        createdAt: now,
      };

      db.contactSubmissions.unshift(submission);
      saveDatabase(db);

      res.status(201).json({
        ok: true,
        message: 'Thank you. Your book promotion inquiry has been securely received by Edward Duncan Book Promotions.',
        submissionId: submission.id,
      });
    });
  });

  // ==========================================
  // OWNER AUTHENTICATION ROUTES
  // ==========================================

  app.get('/api/auth/me', (req, res) => {
    const session = getAuthenticatedSession(req);
    if (!session) {
      res.json({ authenticated: false });
      return;
    }
    const db = loadDatabase();
    res.json({
      authenticated: true,
      owner: {
        email: db.owner.email,
        lastLoginAt: db.owner.lastLoginAt,
        updatedAt: db.owner.updatedAt,
      },
    });
  });

  app.post('/api/auth/login', (req, res) => {
    const ip = req.ip || 'unknown';
    if (!checkRateLimit(ip)) {
      res.status(429).json({ error: 'Too many sign-in attempts. Please wait 15 minutes before trying again.' });
      return;
    }

    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');

    if (!email || !password) {
      res.status(400).json({ error: 'Email address and password are required.' });
      return;
    }

    const db = loadDatabase();
    const emailMatches = email === db.owner.email.toLowerCase();
    const passwordValid = emailMatches && verifyPassword(password, db.owner.passwordSalt, db.owner.passwordHash);

    if (!passwordValid) {
      res.status(401).json({ error: 'Invalid owner credentials.' });
      return;
    }

    const rawToken = generateSessionToken();
    const now = new Date();
    const expiresAt = new Date(now.getTime() + SESSION_TTL_MS).toISOString();

    db.sessions.unshift({
      id: `sess-${crypto.randomUUID()}`,
      tokenHash: hashToken(rawToken),
      createdAt: now.toISOString(),
      expiresAt,
      userAgent: String(req.headers['user-agent'] || 'Unknown Browser').slice(0, 180),
      ipAddress: ip,
    });
    db.owner.lastLoginAt = now.toISOString();
    saveDatabase(db);

    const signedCookie = signSessionValue(rawToken, db.sessionSecret);
    res.cookie(SESSION_COOKIE, signedCookie, getCookieOptions(req, SESSION_TTL_MS));
    res.json({
      authenticated: true,
      sessionToken: signedCookie,
      owner: {
        email: db.owner.email,
        lastLoginAt: db.owner.lastLoginAt,
        updatedAt: db.owner.updatedAt,
      },
    });
  });

  app.post('/api/auth/logout', (req, res) => {
    const db = loadDatabase();
    const rawCookie = extractSignedTokenFromRequest(req);
    const token = verifySignedSessionValue(rawCookie, db.sessionSecret);
    if (token) {
      const tokenHash = hashToken(token);
      db.sessions = db.sessions.filter((s) => s.tokenHash !== tokenHash);
      saveDatabase(db);
    }
    res.clearCookie(SESSION_COOKIE, getCookieOptions(req));
    res.json({ ok: true });
  });

  app.post('/api/auth/request-reset', (req, res) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const db = loadDatabase();
    if (email && email === db.owner.email.toLowerCase()) {
      const resetCode = generateResetCode();
      db.owner.resetTokenHash = hashToken(resetCode);
      db.owner.resetTokenExpiresAt = new Date(Date.now() + RESET_TTL_MS).toISOString();
      saveDatabase(db);
      console.log(`[AUTH] Owner password reset code for ${db.owner.email} (valid 15 min): ${resetCode}`);
    }
    res.json({
      ok: true,
      message:
        'If the provided email matches the authorized owner account, a 15-minute reset code has been generated in the server security log. You may also authorize the reset using your saved Owner Recovery Key.',
    });
  });

  app.post('/api/auth/reset-password', (req, res) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const verificationCode = String(req.body?.verificationCode || '').trim().toUpperCase();
    const newPassword = String(req.body?.newPassword || '');

    if (!email || !verificationCode || !newPassword) {
      res.status(400).json({ error: 'All fields are required to reset the owner password.' });
      return;
    }

    if (newPassword.length < 8) {
      res.status(400).json({ error: 'New password must be at least 8 characters long.' });
      return;
    }

    const db = loadDatabase();
    if (email !== db.owner.email.toLowerCase()) {
      res.status(403).json({ error: 'Verification failed. Check your owner email and reset code or recovery key.' });
      return;
    }

    const providedHash = hashToken(verificationCode);
    const hasValidResetCode =
      Boolean(db.owner.resetTokenHash) &&
      Boolean(db.owner.resetTokenExpiresAt) &&
      new Date(db.owner.resetTokenExpiresAt as string).getTime() > Date.now() &&
      providedHash === db.owner.resetTokenHash;

    const hasValidRecoveryKey = providedHash === db.owner.recoveryKeyHash;

    if (!hasValidResetCode && !hasValidRecoveryKey) {
      res.status(403).json({ error: 'Invalid or expired reset code / recovery key.' });
      return;
    }

    const { salt, hash } = hashPassword(newPassword);
    db.owner.passwordSalt = salt;
    db.owner.passwordHash = hash;
    db.owner.resetTokenHash = null;
    db.owner.resetTokenExpiresAt = null;
    db.owner.updatedAt = new Date().toISOString();
    // Invalidate all prior active sessions for security
    db.sessions = [];
    saveDatabase(db);

    res.clearCookie(SESSION_COOKIE, getCookieOptions(req));
    res.json({
      ok: true,
      message: 'Owner password has been securely updated. Please sign in with your new password.',
    });
  });

  // ==========================================
  // PROTECTED OWNER-ONLY ADMIN ROUTES
  // ==========================================

  app.get('/api/admin/bootstrap', requireAdmin, (req: AuthenticatedRequest, res) => {
    const db = loadDatabase();
    res.json({
      owner: {
        email: db.owner.email,
        lastLoginAt: db.owner.lastLoginAt,
        updatedAt: db.owner.updatedAt,
        recoveryKeyPreview: db.owner.recoveryKeyPreview,
      },
      currentSessionId: req.adminSessionId,
      sessions: db.sessions.map((s) => ({
        id: s.id,
        createdAt: s.createdAt,
        expiresAt: s.expiresAt,
        userAgent: s.userAgent,
        ipAddress: s.ipAddress,
        isCurrent: s.id === req.adminSessionId,
      })),
      settings: db.settings,
      homepage: db.homepage,
      about: db.about,
      pagesCopy: db.pagesCopy,
      services: [...db.services].sort((a, b) => a.order - b.order),
      portfolio: [...db.portfolio].sort((a, b) => b.publicationDate.localeCompare(a.publicationDate)),
      featuredBooks: db.featuredBooks,
      authors: db.authors,
      testimonials: db.testimonials,
      contactSubmissions: db.contactSubmissions,
      mediaLibrary: db.mediaLibrary,
    });
  });

  // Homepage & About & Settings
  app.put('/api/admin/homepage', requireAdmin, (req, res) => {
    const db = loadDatabase();
    db.homepage = { ...db.homepage, ...req.body };
    saveDatabase(db);
    res.json({ homepage: db.homepage });
  });

  app.put('/api/admin/about', requireAdmin, (req, res) => {
    const db = loadDatabase();
    db.about = { ...db.about, ...req.body };
    saveDatabase(db);
    res.json({ about: db.about });
  });

  app.put('/api/admin/settings', requireAdmin, (req, res) => {
    const db = loadDatabase();
    db.settings = {
      ...db.settings,
      ...req.body,
      socialLinks: {
        ...db.settings.socialLinks,
        ...(req.body?.socialLinks || {}),
      },
    };
    saveDatabase(db);
    res.json({ settings: db.settings });
  });

  app.put('/api/admin/pages-copy', requireAdmin, (req, res) => {
    const db = loadDatabase();
    db.pagesCopy = { ...db.pagesCopy, ...req.body };
    saveDatabase(db);
    res.json({ pagesCopy: db.pagesCopy });
  });

  // Services CRUD
  app.post('/api/admin/services', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const title = String(req.body.title || '').trim();
    if (!title) {
      res.status(400).json({ error: 'Service title is required.' });
      return;
    }
    const service: ServiceItem = {
      id: `svc-${crypto.randomUUID()}`,
      title,
      slug: slugify(title),
      shortDescription: String(req.body.shortDescription || '').trim(),
      fullDescription: String(req.body.fullDescription || '').trim(),
      deliverables: Array.isArray(req.body.deliverables) ? req.body.deliverables.filter(Boolean) : [],
      imageUrl: String(req.body.imageUrl || '/src/assets/images/service_author_spotlight_1795012457843.jpg'),
      featuredOnHome: Boolean(req.body.featuredOnHome),
      order: Number(req.body.order) || db.services.length + 1,
      active: req.body.active !== false,
    };
    db.services.push(service);
    saveDatabase(db);
    res.status(201).json({ service });
  });

  app.put('/api/admin/services/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const idx = db.services.findIndex((s) => s.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'Service not found.' });
      return;
    }
    const existing = db.services[idx];
    const updated: ServiceItem = {
      ...existing,
      ...req.body,
      id: existing.id,
      slug: req.body.title ? slugify(String(req.body.title)) : existing.slug,
      deliverables: Array.isArray(req.body.deliverables) ? req.body.deliverables.filter(Boolean) : existing.deliverables,
    };
    db.services[idx] = updated;
    saveDatabase(db);
    res.json({ service: updated });
  });

  app.delete('/api/admin/services/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    db.services = db.services.filter((s) => s.id !== req.params.id);
    saveDatabase(db);
    res.json({ ok: true });
  });

  // Portfolio CRUD
  app.post('/api/admin/portfolio', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const projectTitle = String(req.body.projectTitle || '').trim();
    if (!projectTitle) {
      res.status(400).json({ error: 'Project title is required.' });
      return;
    }
    const item: PortfolioItem = {
      id: `port-${crypto.randomUUID()}`,
      projectTitle,
      authorName: String(req.body.authorName || '').trim(),
      bookTitle: String(req.body.bookTitle || '').trim(),
      bookCoverUrl: String(req.body.bookCoverUrl || '').trim(),
      bannerImageUrl: String(req.body.bannerImageUrl || '').trim(),
      videoUrl: String(req.body.videoUrl || '').trim(),
      videoType: (req.body.videoType as PortfolioItem['videoType']) || (req.body.videoUrl ? 'external' : 'none'),
      description: String(req.body.description || '').trim(),
      category: (req.body.category as PortfolioCategory) || 'Promotional Projects',
      publicationDate: String(req.body.publicationDate || new Date().toISOString().slice(0, 10)),
      featuredOnHome: Boolean(req.body.featuredOnHome),
      createdAt: new Date().toISOString(),
    };
    db.portfolio.unshift(item);
    saveDatabase(db);
    res.status(201).json({ item });
  });

  app.put('/api/admin/portfolio/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const idx = db.portfolio.findIndex((p) => p.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'Portfolio item not found.' });
      return;
    }
    const updated: PortfolioItem = {
      ...db.portfolio[idx],
      ...req.body,
      id: db.portfolio[idx].id,
    };
    db.portfolio[idx] = updated;
    saveDatabase(db);
    res.json({ item: updated });
  });

  app.delete('/api/admin/portfolio/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    db.portfolio = db.portfolio.filter((p) => p.id !== req.params.id);
    saveDatabase(db);
    res.json({ ok: true });
  });

  // Featured Books CRUD
  app.post('/api/admin/books', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const bookTitle = String(req.body.bookTitle || '').trim();
    if (!bookTitle) {
      res.status(400).json({ error: 'Book title is required.' });
      return;
    }
    const book: FeaturedBook = {
      id: `book-${crypto.randomUUID()}`,
      bookTitle,
      authorName: String(req.body.authorName || '').trim(),
      genre: String(req.body.genre || '').trim(),
      shortDescription: String(req.body.shortDescription || '').trim(),
      promotionalNotes: String(req.body.promotionalNotes || '').trim(),
      bookCoverUrl: String(req.body.bookCoverUrl || '').trim(),
      promotionalBannerUrl: String(req.body.promotionalBannerUrl || '').trim(),
      trailerUrl: String(req.body.trailerUrl || '').trim(),
      purchaseLink: String(req.body.purchaseLink || '').trim(),
      spotlightStory: String(req.body.spotlightStory || '').trim(),
      featuredOnHome: Boolean(req.body.featuredOnHome),
      createdAt: new Date().toISOString(),
    };
    db.featuredBooks.unshift(book);
    saveDatabase(db);
    res.status(201).json({ book });
  });

  app.put('/api/admin/books/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const idx = db.featuredBooks.findIndex((b) => b.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'Featured book not found.' });
      return;
    }
    const updated: FeaturedBook = {
      ...db.featuredBooks[idx],
      ...req.body,
      id: db.featuredBooks[idx].id,
    };
    db.featuredBooks[idx] = updated;
    saveDatabase(db);
    res.json({ book: updated });
  });

  app.delete('/api/admin/books/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    db.featuredBooks = db.featuredBooks.filter((b) => b.id !== req.params.id);
    saveDatabase(db);
    res.json({ ok: true });
  });

  // Authors CRUD
  app.post('/api/admin/authors', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const fullName = String(req.body.fullName || '').trim();
    if (!fullName) {
      res.status(400).json({ error: 'Author full name is required.' });
      return;
    }
    const author: AuthorProfile = {
      id: `author-${crypto.randomUUID()}`,
      fullName,
      penName: String(req.body.penName || fullName).trim(),
      genres: Array.isArray(req.body.genres)
        ? req.body.genres.filter(Boolean)
        : String(req.body.genres || '')
            .split(',')
            .map((g) => g.trim())
            .filter(Boolean),
      bio: String(req.body.bio || '').trim(),
      photoUrl: String(req.body.photoUrl || '').trim(),
      website: String(req.body.website || '').trim(),
      socialLink: String(req.body.socialLink || '').trim(),
      featuredBooksCount: Number(req.body.featuredBooksCount) || 1,
      createdAt: new Date().toISOString(),
    };
    db.authors.unshift(author);
    saveDatabase(db);
    res.status(201).json({ author });
  });

  app.put('/api/admin/authors/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const idx = db.authors.findIndex((a) => a.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'Author profile not found.' });
      return;
    }
    const existing = db.authors[idx];
    const genres = Array.isArray(req.body.genres)
      ? req.body.genres.filter(Boolean)
      : typeof req.body.genres === 'string'
        ? req.body.genres.split(',').map((g: string) => g.trim()).filter(Boolean)
        : existing.genres;
    const updated: AuthorProfile = {
      ...existing,
      ...req.body,
      genres,
      id: existing.id,
    };
    db.authors[idx] = updated;
    saveDatabase(db);
    res.json({ author: updated });
  });

  app.delete('/api/admin/authors/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    db.authors = db.authors.filter((a) => a.id !== req.params.id);
    saveDatabase(db);
    res.json({ ok: true });
  });

  // Testimonials CRUD
  app.post('/api/admin/testimonials', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const authorName = String(req.body.authorName || '').trim();
    const testimonialText = String(req.body.testimonialText || '').trim();
    if (!authorName || !testimonialText) {
      res.status(400).json({ error: 'Author name and testimonial text are required.' });
      return;
    }
    const testimonial: TestimonialItem = {
      id: `test-${crypto.randomUUID()}`,
      authorName,
      authorPhotoUrl: String(req.body.authorPhotoUrl || '').trim(),
      bookTitle: String(req.body.bookTitle || '').trim(),
      bookCoverUrl: String(req.body.bookCoverUrl || '').trim(),
      testimonialText,
      authorLink: String(req.body.authorLink || '').trim(),
      rating: req.body.rating ? Number(req.body.rating) : undefined,
      published: req.body.published !== false,
      isPlaceholder: Boolean(req.body.isPlaceholder),
      createdAt: new Date().toISOString(),
    };
    db.testimonials.unshift(testimonial);
    saveDatabase(db);
    res.status(201).json({ testimonial });
  });

  app.put('/api/admin/testimonials/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const idx = db.testimonials.findIndex((t) => t.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'Testimonial not found.' });
      return;
    }
    const updated: TestimonialItem = {
      ...db.testimonials[idx],
      ...req.body,
      id: db.testimonials[idx].id,
    };
    db.testimonials[idx] = updated;
    saveDatabase(db);
    res.json({ testimonial: updated });
  });

  app.delete('/api/admin/testimonials/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    db.testimonials = db.testimonials.filter((t) => t.id !== req.params.id);
    saveDatabase(db);
    res.json({ ok: true });
  });

  // Contact Form Submissions Management
  app.patch('/api/admin/submissions/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const idx = db.contactSubmissions.findIndex((s) => s.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'Submission not found.' });
      return;
    }
    const allowedStatuses: SubmissionStatus[] = ['New', 'Reviewed', 'Replied', 'Archived'];
    const nextStatus = allowedStatuses.includes(req.body.status)
      ? (req.body.status as SubmissionStatus)
      : db.contactSubmissions[idx].status;

    db.contactSubmissions[idx] = {
      ...db.contactSubmissions[idx],
      status: nextStatus,
      adminNotes:
        typeof req.body.adminNotes === 'string'
          ? req.body.adminNotes
          : db.contactSubmissions[idx].adminNotes,
    };
    saveDatabase(db);
    res.json({ submission: db.contactSubmissions[idx] });
  });

  app.delete('/api/admin/submissions/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    db.contactSubmissions = db.contactSubmissions.filter((s) => s.id !== req.params.id);
    saveDatabase(db);
    res.json({ ok: true });
  });

  // Media Upload Center & Library
  app.post('/api/admin/upload', requireAdmin, (req, res) => {
    adminUpload.single('file')(req, res, (err) => {
      if (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'Upload failed.' });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: 'No file selected for upload.' });
        return;
      }

      const db = loadDatabase();
      const assetType = (req.body.assetType as MediaAssetType) || 'general';
      const title = String(req.body.title || req.file.originalname).trim();
      const asset: MediaAsset = {
        id: `media-${crypto.randomUUID()}`,
        filename: req.file.filename,
        originalName: req.file.originalname,
        url: `/uploads/${req.file.filename}`,
        mimeType: req.file.mimetype,
        sizeBytes: req.file.size,
        assetType,
        title,
        createdAt: new Date().toISOString(),
      };
      db.mediaLibrary.unshift(asset);
      saveDatabase(db);
      res.status(201).json({ asset });
    });
  });

  app.delete('/api/admin/media/:id', requireAdmin, (req, res) => {
    const db = loadDatabase();
    const asset = db.mediaLibrary.find((m) => m.id === req.params.id);
    if (!asset) {
      res.status(404).json({ error: 'Media asset not found.' });
      return;
    }
    if (asset.url.startsWith('/uploads/')) {
      const filePath = path.join(UPLOADS_DIR, path.basename(asset.url));
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }
    db.mediaLibrary = db.mediaLibrary.filter((m) => m.id !== req.params.id);
    saveDatabase(db);
    res.json({ ok: true });
  });

  // Security & Account Settings
  app.post('/api/admin/security/change-password', requireAdmin, (req, res) => {
    const currentPassword = String(req.body?.currentPassword || '');
    const newPassword = String(req.body?.newPassword || '');
    if (!currentPassword || !newPassword) {
      res.status(400).json({ error: 'Current password and new password are required.' });
      return;
    }
    if (newPassword.length < 8) {
      res.status(400).json({ error: 'New password must be at least 8 characters long.' });
      return;
    }
    const db = loadDatabase();
    if (!verifyPassword(currentPassword, db.owner.passwordSalt, db.owner.passwordHash)) {
      res.status(403).json({ error: 'Current password is incorrect.' });
      return;
    }
    const { salt, hash } = hashPassword(newPassword);
    db.owner.passwordSalt = salt;
    db.owner.passwordHash = hash;
    db.owner.updatedAt = new Date().toISOString();
    saveDatabase(db);
    res.json({ ok: true, message: 'Owner password updated successfully.' });
  });

  app.post('/api/admin/security/change-email', requireAdmin, (req, res) => {
    const currentPassword = String(req.body?.currentPassword || '');
    const newEmail = String(req.body?.newEmail || '').trim().toLowerCase();
    if (!currentPassword || !newEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) {
      res.status(400).json({ error: 'Valid new email and current password are required.' });
      return;
    }
    const db = loadDatabase();
    if (!verifyPassword(currentPassword, db.owner.passwordSalt, db.owner.passwordHash)) {
      res.status(403).json({ error: 'Current password is incorrect.' });
      return;
    }
    db.owner.email = newEmail;
    db.owner.updatedAt = new Date().toISOString();
    saveDatabase(db);
    res.json({ ok: true, email: db.owner.email });
  });

  app.post('/api/admin/security/regenerate-recovery-key', requireAdmin, (req, res) => {
    const currentPassword = String(req.body?.currentPassword || '');
    const db = loadDatabase();
    if (!verifyPassword(currentPassword, db.owner.passwordSalt, db.owner.passwordHash)) {
      res.status(403).json({ error: 'Please verify your current password to regenerate the recovery key.' });
      return;
    }
    const newKey = generateRecoveryKey();
    db.owner.recoveryKeyHash = hashToken(newKey);
    db.owner.recoveryKeyPreview = `${newKey.slice(0, 9)}••••${newKey.slice(-4)}`;
    db.owner.updatedAt = new Date().toISOString();
    saveDatabase(db);
    res.json({
      ok: true,
      recoveryKey: newKey,
      recoveryKeyPreview: db.owner.recoveryKeyPreview,
    });
  });

  app.delete('/api/admin/security/sessions/:id', requireAdmin, (req: AuthenticatedRequest, res) => {
    const db = loadDatabase();
    db.sessions = db.sessions.filter((s) => s.id !== req.params.id);
    saveDatabase(db);
    res.json({ ok: true });
  });

  // Unknown API routes return JSON 404
  app.use('/api/*', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  // Frontend mounting (Vite middleware in dev, static dist in production)
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Edward Duncan Book Promotions server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
