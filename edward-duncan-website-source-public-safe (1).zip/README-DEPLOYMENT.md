# Edward Duncan Book Promotions

## Run locally
1. Install Node.js 22 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set the environment variables.
4. Run `npm run dev` for development.
5. Run `npm run build` to create the production frontend.
6. Run `npm start` to start the Express server.

## Deployment notes
This is a full-stack React + Express application. It is not compatible with GitHub Pages alone.
The Express server currently stores its database in `data/store.json` and uploaded media in `uploads/`.
Those locations require persistent storage in production. Do not deploy with ephemeral storage if
you need admin edits, inquiries, or uploaded media to survive restarts.

Configure these environment variables in the hosting provider:
- `ADMIN_EMAIL`
- `ADMIN_INITIAL_PASSWORD` (the owner-selected password)
- `SESSION_SECRET` (a long random secret)

Never commit `.env`, `data/store.json`, or `uploads/` to Git.
