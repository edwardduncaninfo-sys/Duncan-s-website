import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type {
  AboutContent,
  AuthorProfile,
  ContactSubmission,
  FeaturedBook,
  HomepageContent,
  MediaAsset,
  PagesCopyContent,
  PortfolioItem,
  PublicSiteData,
  ServiceItem,
  TestimonialItem,
  WebsiteSettings,
} from '../src/types/cms.ts';
import { generateRecoveryKey, hashPassword, hashToken } from './auth.ts';

export interface AdminSessionRecord {
  id: string;
  tokenHash: string;
  createdAt: string;
  expiresAt: string;
  userAgent: string;
  ipAddress: string;
}

export interface OwnerAccount {
  email: string;
  passwordSalt: string;
  passwordHash: string;
  recoveryKeyHash: string;
  recoveryKeyPreview: string;
  resetTokenHash: string | null;
  resetTokenExpiresAt: string | null;
  lastLoginAt: string | null;
  updatedAt: string;
}

export interface DatabaseSchema {
  sessionSecret: string;
  owner: OwnerAccount;
  sessions: AdminSessionRecord[];
  settings: WebsiteSettings;
  homepage: HomepageContent;
  about: AboutContent;
  pagesCopy: PagesCopyContent;
  services: ServiceItem[];
  portfolio: PortfolioItem[];
  featuredBooks: FeaturedBook[];
  authors: AuthorProfile[];
  testimonials: TestimonialItem[];
  contactSubmissions: ContactSubmission[];
  mediaLibrary: MediaAsset[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'store.json');

export function createDefaultPagesCopy(): PagesCopyContent {
  return {
    navHomeLabel: 'Homepage',
    navAboutLabel: 'About',
    navServicesLabel: 'Services',
    navPortfolioLabel: 'Portfolio',
    navBooksLabel: 'Featured Books',
    navContactLabel: 'Contact',
    navAdminLabel: 'Admin Dashboard',
    headerCtaLabel: 'Get a Quote',
    footerInquiriesLabel: 'Direct Inquiries:',
    footerNavHeading: 'Agency Navigation',
    footerConnectHeading: 'Connect',
    footerCtaLabel: 'Request Campaign Consultation',

    requestServiceLabel: 'Request This Service',
    inspectCampaignLabel: 'Inspect Campaign',
    videoPreviewLabel: 'Video Preview',
    viewFeatureLabel: 'View Promotional Feature',
    bookLinkLabel: 'Book Link',
    authorWebsiteLabel: 'Author Website',
    authorSocialLabel: 'Social Profile',
    emptyTestimonialsText:
      'Verified author testimonials will appear here once published in the agency administration dashboard.',
    modalRequestCampaignLabel: 'Request a Similar Campaign',

    servicesKicker: 'Book Marketing Services',
    servicesHeading: 'Strategic Promotional Campaigns Built for Serious Authors',
    servicesSubheading:
      'Select individual services or combine multiple promotional pillars into a cohesive campaign tailored to your book’s genre, goals, and launch timeline.',
    serviceNumberPrefix: 'Service',
    deliverablesHeading: 'Included Deliverables',
    servicesBottomHeading: 'Not Sure Which Promotional Package Fits Your Book?',
    servicesBottomBody:
      'Share your book title, genre, and publishing stage for a personalized recommendation from Edward Duncan.',
    servicesBottomCta: 'Get a Promotion Quote',

    portfolioKicker: 'Promotional Portfolio',
    portfolioHeading: 'Featured Work, Banners & Cinematic Book Trailers',
    portfolioSubheading:
      'Explore promotional campaigns, custom author spotlight banners, book trailer productions, and book presentation work managed by Edward Duncan Book Promotions.',
    portfolioAllFilterLabel: 'All Work',
    portfolioWatchTrailerLabel: 'Watch Trailer',
    portfolioViewDetailsLabel: 'View Project Details',
    portfolioInquireLabel: 'Inquire',
    portfolioModalBookLabel: 'Featured Book & Author',
    portfolioModalCtaLabel: 'Request This Campaign Style',

    booksKicker: 'Featured Books & Authors',
    booksHeading: 'Showcased Titles & Author Spotlights',
    booksSubheading:
      'Explore featured books whose promotional assets, spotlight features, and visibility campaigns have been curated by Edward Duncan Book Promotions.',
    bookStoreShortLabel: 'Amazon / Store',
    authorsKicker: 'Author Directory',
    authorsHeading: 'Featured Authors',
    backToBooksLabel: 'All Featured Books',
    bookAboutHeading: 'About the Book',
    bookSpotlightHeading: 'Promotional Spotlight & Positioning',
    bookPromoScopeLabel: 'Promotional Materials & Scope',
    bookPurchaseLabel: 'View on Amazon / Book Store',
    bookPromoteCtaLabel: 'Promote Your Book Like This',
    bookBannerHeading: 'Promotional Banner Feature',
    bookTrailerHeading: 'Official Book Trailer',

    contactKicker: 'Book Promotion Inquiry',
    contactHeading: 'Request a Tailored Promotion Quote',
    contactSubheading:
      'Tell us about your book, publishing timeline, and promotional goals. All inquiries are reviewed directly by Edward Duncan.',
    contactFormHeading: 'Book Promotion Request Form',
    contactNameLabel: 'Full Name',
    contactEmailLabel: 'Email Address',
    contactBookTitleLabel: 'Book Title',
    contactGenreLabel: 'Book Genre',
    contactWebsiteLabel: 'Author Website (Optional)',
    contactServiceLabel: 'Requested Service',
    contactExtraServiceOption: 'Full Campaign Consultation',
    contactMessageLabel: 'Message & Campaign Goals',
    contactUploadLabel: 'Optional Book Cover Upload (JPG, PNG, WebP · Max 10MB)',
    contactUploadHint: 'Attach your current cover artwork for visual review if available.',
    contactSubmitLabel: 'Submit Promotion Request',
    contactSuccessTitle: 'Inquiry Received',
    contactSidebarKicker: 'Direct Agency Contact',
    contactSidebarEmailLabel: 'Business Email',
    contactSidebarLocationLabel: 'Availability',
    contactSidebarChannelsLabel: 'Agency Channels',
  };
}

function createDefaultHomepageExtensions() {
  return {
    heroKicker: 'Edward Duncan Book Promotions · Book Promotion Specialist',
    introPillars: [
      { title: 'Independent & Traditional', subtitle: 'Tailored guidance across publishing paths' },
      { title: 'Global Reach', subtitle: 'Supporting authors and publishers worldwide' },
      { title: 'Bespoke Assets', subtitle: 'Spotlights, banners, trailers & audits' },
    ],
    introCtaLabel: 'Read About Edward Duncan',
    showcaseKicker: 'Promotional Showcase',
    showcaseCtaLabel: 'Explore Full Portfolio',
    servicesKicker: 'Core Agency Capabilities',
    servicesCtaLabel: 'View All Services',
    successStoriesKicker: 'Featured Books & Authors',
    successStoriesCtaLabel: 'Browse Featured Books',
    testimonialsKicker: 'Client Feedback',
    ctaKicker: 'Start Your Campaign',
  };
}

function createDefaultAboutExtensions() {
  return {
    heroKicker: 'About the Specialist',
    missionLabel: 'Our Mission',
    missionHeading: 'Purposeful Author Visibility',
    visionLabel: 'Our Vision',
    visionHeading: 'Agency Standards for Every Writer',
    approachKicker: 'Methodology',
    approachHeading: 'Our Approach to Book Marketing',
    approachSubheading:
      'Every campaign follows a disciplined four-stage framework designed for discoverability, credibility, and lasting reader connection.',
    commitmentKicker: 'Commitment to Authors',
    whyHeading: 'Why Authors Partner With Edward Duncan Book Promotions',
    primaryCtaLabel: 'Explore Promotional Services',
    secondaryCtaLabel: 'Discuss Your Book',
  };
}

function createInitialSeed(): { db: DatabaseSchema; initialRecoveryKey: string; initialPassword: string } {
  const initialEmail = (process.env.ADMIN_EMAIL || 'edwardduncan.info@gmail.com').trim().toLowerCase();
  const initialPassword = process.env.ADMIN_INITIAL_PASSWORD;
  if (!initialPassword || initialPassword === 'CHANGE_ME_ON_FIRST_LOGIN') {
    throw new Error('Set ADMIN_INITIAL_PASSWORD in the hosting provider environment before the first startup.');
  }

  const { salt, hash } = hashPassword(initialPassword);
  const initialRecoveryKey = generateRecoveryKey();
  const now = new Date().toISOString();
  const homeExt = createDefaultHomepageExtensions();
  const aboutExt = createDefaultAboutExtensions();

  const db: DatabaseSchema = {
    sessionSecret:
      process.env.SESSION_SECRET && process.env.SESSION_SECRET !== 'REPLACE_WITH_RANDOM_HEX_SECRET'
        ? process.env.SESSION_SECRET
        : crypto.randomBytes(32).toString('hex'),
    owner: {
      email: initialEmail,
      passwordSalt: salt,
      passwordHash: hash,
      recoveryKeyHash: hashToken(initialRecoveryKey),
      recoveryKeyPreview: `${initialRecoveryKey.slice(0, 9)}••••${initialRecoveryKey.slice(-4)}`,
      resetTokenHash: null,
      resetTokenExpiresAt: null,
      lastLoginAt: null,
      updatedAt: now,
    },
    sessions: [],
    settings: {
      businessName: 'Edward Duncan Book Promotions',
      specialistName: 'Edward Duncan',
      specialistTitle: 'Book Promotion Specialist',
      businessDescription:
        'Helping authors increase book visibility, strengthen their author brands, reach relevant readers, and present their books professionally through strategic promotional campaigns.',
      contactEmail: 'edwardduncan.info@gmail.com',
      location: 'London & International Remote',
      socialLinks: {
        linkedin: 'https://www.linkedin.com',
        instagram: 'https://www.instagram.com',
        x: 'https://x.com',
        facebook: '',
        youtube: '',
      },
      footerNote: 'Strategic Book Marketing, Author Branding & Literary Visibility Worldwide.',
      seoTitle: 'Edward Duncan Book Promotions | Strategic Book Marketing Agency',
      seoDescription:
        'Helping authors increase book visibility, strengthen their author brands, reach relevant readers, and present their books professionally through strategic promotional campaigns.',
    },
    homepage: {
      ...homeExt,
      heroHeadline: 'Your Story Deserves to Be Discovered.',
      heroSubheadline:
        'Edward Duncan Book Promotions partners with independent, hybrid, and traditionally published authors worldwide to elevate book visibility, sharpen author branding, and connect compelling titles with engaged readers.',
      heroImageUrl: '/src/assets/images/hero_literary_agency_1795012457583.jpg',
      primaryCtaLabel: 'Explore Our Services',
      secondaryCtaLabel: 'Get a Promotion Quote',
      introKicker: 'Meet the Specialist',
      introHeading: 'Strategic Advocacy for Authors Who Take Their Craft Seriously',
      introBody:
        'Great books rarely fail for lack of merit—they struggle for lack of structured visibility. Led by Book Promotion Specialist Edward Duncan, our agency builds cohesive promotional ecosystems combining editorial spotlights, bespoke visual presentation, Amazon optimization and A+ Content, and targeted reader outreach.',
      introPortraitUrl: '/src/assets/images/edward_duncan_portrait_1795012457373.jpg',
      showcaseHeading: 'Curated Promotional Craft',
      showcaseSubheading:
        'From hardcover presentation and custom author spotlight banners to cinematic book trailers, every asset is designed to meet international publishing standards.',
      servicesHeading: 'Comprehensive Book Promotion Services',
      servicesSubheading:
        'Tailored promotional pillars engineered to strengthen discoverability, authority, and reader engagement at every stage of your book’s lifecycle.',
      successStoriesHeading: 'Featured Books & Promotional Campaigns',
      successStoriesSubheading:
        'Explore recent book showcases, visual campaigns, and strategic promotional features managed through the agency.',
      testimonialsHeading: 'Author Perspectives & Client Feedback',
      testimonialsSubheading:
        'Genuine author reviews and campaign reflections appear below as they are verified and published.',
      ctaHeading: 'Ready to Position Your Book for Wider Readership?',
      ctaBody:
        'Share your manuscript details, publication goals, or upcoming launch timeline to receive a tailored promotional recommendation.',
      ctaButtonLabel: 'Request a Promotion Quote',
    },
    about: {
      ...aboutExt,
      heroHeading: 'Dedicated to Helping Remarkable Books Find Their Rightful Readers',
      heroSubheading:
        'Edward Duncan Book Promotions bridges the gap between literary craftsmanship and strategic global visibility.',
      portraitUrl: '/src/assets/images/edward_duncan_portrait_1795012457373.jpg',
      specialistName: 'Edward Duncan',
      specialistTitle: 'Book Promotion Specialist & Agency Founder',
      biography: [
        'Edward Duncan is a dedicated Book Promotion Specialist who works closely with independent authors, traditionally published writers, and boutique publishers around the world. Recognizing that talented authors often spend years perfecting a manuscript only to face a crowded and noisy marketplace alone, Edward founded Edward Duncan Book Promotions to provide structured, dignified, and results-oriented literary marketing.',
        'Rather than relying on generic automated blasts or hollow vanity metrics, Edward focuses on the fundamentals that genuinely influence reader trust: compelling visual presentation, clear positioning, Amazon optimization and discoverability architecture, and sustained reader-facing storytelling.',
        'Every campaign is built around the unique voice, genre expectations, and long-term career trajectory of the author—treating each title not as a fleeting release, but as an enduring cultural asset.',
      ],
      mission:
        'To empower authors worldwide with strategic, transparent, and professionally executed book promotion campaigns that elevate credibility and cultivate lasting readership.',
      vision:
        'A literary landscape where dedicated writers—whether debut independents or established voices—have access to agency-grade branding, visual production, and discoverability strategy.',
      marketingApproach: [
        {
          title: '01. Positioning & Audience Alignment',
          description:
            'We begin by clarifying who your ideal reader is, how your book sits within its genre conventions, and what narrative hook differentiates it from competing titles.',
        },
        {
          title: '02. Editorial & Visual Authority',
          description:
            'Readers judge presentation in seconds. We craft cohesive promotional banners, author spotlights, and cinematic trailers that reflect the polish of top publishing houses.',
        },
        {
          title: '03. Amazon Optimization & Discoverability',
          description:
            'Through comprehensive Book Visibility Audits and Amazon Optimization (A+ Content, categories, keywords, and retail copy), we align your storefront so readers actively find and convert on your work.',
        },
        {
          title: '04. Sustained Reader Engagement',
          description:
            'Launch week is only the opening chapter. We design structured campaigns that spark conversations across social channels and dedicated reader communities.',
        },
      ],
      commitmentStatement:
        'Every author who entrusts their book to Edward Duncan Book Promotions receives attentive, bespoke guidance, honest strategic feedback, and promotional materials crafted with respect for the written word.',
      whyWorkWithUs: [
        {
          title: 'Bespoke Literary Strategy',
          description:
            'No cookie-cutter templates. Every banner, trailer concept, and visibility plan is tailored to your specific genre and reader demographic.',
        },
        {
          title: 'End-to-End Presentation',
          description:
            'From deep-dive Amazon optimization and A+ Content to finished visual media and author spotlights, your entire promotional footprint works in harmony.',
        },
        {
          title: 'Global Author Perspective',
          description:
            'We support debut self-published novelists, nonfiction thought leaders, and traditionally published authors across North America, Europe, and beyond.',
        },
        {
          title: 'Transparent Collaboration',
          description:
            'Direct communication, clear deliverables, and practical recommendations you can implement immediately.',
        },
      ],
    },
    pagesCopy: createDefaultPagesCopy(),
    services: [
      {
        id: 'svc-amazon-optimization',
        title: 'Amazon Optimization',
        slug: 'amazon-optimization',
        shortDescription:
          'Strategic Amazon KDP optimization covering backend keywords, niche categories, HTML book descriptions, and retail search discoverability.',
        fullDescription:
          'Ensure your book is properly indexed and positioned where active buyers are searching. Our Amazon Optimization service refines your KDP backend keyword slots, niche browse categories, editorial book description formatting, and storefront metadata to maximize organic discoverability and reader conversion.',
        deliverables: [
          '7 backend KDP keyword slots researched for buyer intent',
          'High-relevance Amazon category placement recommendations',
          'HTML-formatted book description & persuasive sales hook',
          'Amazon Author Central & Series Page alignment',
        ],
        imageUrl: '/src/assets/images/featured_book_charcoal_1795012459934.jpg',
        featuredOnHome: true,
        order: 1,
        active: true,
      },
      {
        id: 'svc-amazon-a-plus-content',
        title: 'Amazon A+ Content',
        slug: 'amazon-a-plus-content',
        shortDescription:
          'Custom visual Amazon A+ Content modules designed to elevate book presentation, showcase praise, and increase retail page conversion.',
        fullDescription:
          'Turn casual Amazon browsers into committed readers with agency-grade A+ Content below the fold. We design and structure bespoke visual banners, author spotlights, character/theme highlights, and series comparison charts tailored specifically to your book’s aesthetic and genre.',
        deliverables: [
          'Custom multi-module Amazon A+ Content visual graphics',
          'Persuasive editorial story blocks & reader hook copy',
          'Series or backlist comparison table design',
          'KDP-compliant high-resolution image exports ready to upload',
        ],
        imageUrl: '/src/assets/images/featured_book_navy_1795012459296.jpg',
        featuredOnHome: true,
        order: 2,
        active: true,
      },
      {
        id: 'svc-goodreads-profile',
        title: 'Goodreads Profile Optimization',
        slug: 'goodreads-profile-optimization',
        shortDescription:
          'Complete Goodreads Author Program setup, verified profile polishing, book edition linking, and reader-ready presentation.',
        fullDescription:
          'Goodreads is the world’s largest community of dedicated book readers. We optimize your Goodreads Author Profile from the ground up—verifying editions, refining your author biography, linking social channels, adding engaging quotes, and preparing your profile for long-term reader discovery.',
        deliverables: [
          'Goodreads Author Program profile verification & audit',
          'Book metadata, series linking & edition cleanup',
          'Polished author biography, quotes & Q&A setup',
          'Cross-platform reader discovery alignment',
        ],
        imageUrl: '/src/assets/images/service_author_spotlight_1795012457843.jpg',
        featuredOnHome: true,
        order: 3,
        active: true,
      },
      {
        id: 'svc-author-website',
        title: "Author's Website Development",
        slug: 'authors-website-development',
        shortDescription:
          'Custom, mobile-responsive author websites showcasing your books, biography, press kit, newsletter signup, and retail store links.',
        fullDescription:
          'A credible author needs an authoritative home online. We design and build tailored, mobile-responsive author websites built around your literary brand—complete with book showcase pages, retailer purchase links, media/press kits, reader newsletter opt-in forms, and clean SEO structure.',
        deliverables: [
          'Custom responsive author & book showcase website',
          'Dedicated book landing pages with store purchase links',
          'Newsletter capture integration & reader magnet setup',
          'Author biography, press kit & direct contact form',
        ],
        imageUrl: '/src/assets/images/hero_literary_agency_1795012457583.jpg',
        featuredOnHome: true,
        order: 4,
        active: true,
      },
      {
        id: 'svc-book-trailers',
        title: 'Book Trailer & UGC Book Video',
        slug: 'book-trailer-ugc-book-video',
        shortDescription:
          'Cinematic book trailers and scroll-stopping UGC book videos tailored for TikTok (BookTok), Instagram Reels, YouTube, and Amazon.',
        fullDescription:
          'Bring your story to life through motion. We produce both cinematic widescreen book trailers and authentic, short-form UGC (User-Generated Content) style book videos engineered for BookTok, Instagram Reels, YouTube Shorts, and social ad campaigns.',
        deliverables: [
          'Custom trailer or UGC short-form video script & hooks',
          'Full HD 16:9 cinematic book trailer for website & YouTube',
          'Vertical 9:16 UGC book videos for BookTok & Reels',
          'High-impact thumbnail and closing call-to-action frame',
        ],
        imageUrl: '/src/assets/images/service_book_trailer_1795012459207.jpg',
        featuredOnHome: true,
        order: 5,
        active: true,
      },
      {
        id: 'svc-author-newsletter',
        title: 'Author Newsletter & Book Content',
        slug: 'author-newsletter-book-content',
        shortDescription:
          'High-engagement author newsletters, automated reader welcome sequences, and compelling book-focused editorial content.',
        fullDescription:
          'Your mailing list is the only reader audience you truly own. We craft recurring author newsletters, automated welcome sequences, launch countdown emails, and curated book content calendars that deepen reader loyalty and drive consistent launches.',
        deliverables: [
          'Author newsletter strategy & monthly content calendar',
          'Reader welcome email sequence & lead magnet copy',
          'Launch & promotional announcement email campaigns',
          'Engaging social & newsletter book content snippets',
        ],
        imageUrl: '/src/assets/images/service_author_spotlight_1795012457843.jpg',
        featuredOnHome: true,
        order: 6,
        active: true,
      },
      {
        id: 'svc-goodreads-listopia',
        title: 'Goodreads Listopia Placement',
        slug: 'goodreads-listopia-placement',
        shortDescription:
          'Targeted placement of your book onto relevant, active Goodreads Listopia lists to put your title in front of genre readers.',
        fullDescription:
          'Goodreads Listopia lists are curated reading guides frequented by readers actively hunting for their next book. We research high-relevance, genre-matched Listopia lists and strategically place your title to expand organic visibility and shelf additions.',
        deliverables: [
          'Research of active, genre-specific Goodreads Listopia lists',
          'Strategic placement across targeted reading lists',
          'Edition verification to ensure proper cover & link display',
          'Placement summary report with direct list links',
        ],
        imageUrl: '/src/assets/images/featured_book_navy_1795012459296.jpg',
        featuredOnHome: true,
        order: 7,
        active: true,
      },
      {
        id: 'svc-goodreads-review',
        title: 'Goodreads Review Campaigns',
        slug: 'goodreads-review-campaigns',
        shortDescription:
          'Compliant Goodreads reader outreach and ARC review coordination to build authentic reader feedback and social proof.',
        fullDescription:
          'Honest reader reviews are vital for building trust on Goodreads and retail platforms alike. We coordinate ethical, guideline-compliant reader outreach and Advance Reader Copy (ARC) campaigns connecting your book with genuine genre reviewers on Goodreads.',
        deliverables: [
          'Genre-matched Goodreads reader & reviewer outreach',
          'ARC distribution coordination & follow-up timeline',
          'Ethical, Goodreads-compliant review campaign structure',
          'Campaign progress & review tracking summary',
        ],
        imageUrl: '/src/assets/images/featured_book_charcoal_1795012459934.jpg',
        featuredOnHome: true,
        order: 8,
        active: true,
      },
      {
        id: 'svc-author-spotlight',
        title: 'Author Spotlight',
        slug: 'author-spotlight',
        shortDescription:
          'A professional editorial feature highlighting your background, book, writing journey, and literary achievements.',
        fullDescription:
          'Our Author Spotlight service places your voice, creative journey, and latest work front and center in a refined editorial presentation. Designed to build genuine reader connection and media-ready credibility, each spotlight frames your inspirations, thematic focus, and book highlights in persuasive, polished prose.',
        deliverables: [
          'In-depth editorial author profile and Q&A feature',
          'Book synopsis framing and key reader hooks',
          'Dedicated promotional spotlight showcase placement',
          'Shareable feature assets for press kits and newsletters',
        ],
        imageUrl: '/src/assets/images/service_author_spotlight_1795012457843.jpg',
        featuredOnHome: false,
        order: 9,
        active: true,
      },
      {
        id: 'svc-spotlight-banners',
        title: 'Custom Author Spotlight Banners',
        slug: 'custom-author-spotlight-banners',
        shortDescription:
          'Bespoke, publication-grade promotional graphics showcasing you and your book across digital channels.',
        fullDescription:
          'Visual first impressions determine whether scrolling readers pause to investigate your book. We design custom promotional banners, launch graphics, and author spotlight visuals tailored to your cover aesthetic, genre mood, and multi-platform dimensions.',
        deliverables: [
          'Custom hero promotional banner featuring book cover and tagline',
          'Social media aspect ratios for Instagram, X, Facebook, and LinkedIn',
          'Author quote and editorial endorsement visual cards',
          'Print-ready and high-DPI digital export files',
        ],
        imageUrl: '/src/assets/images/featured_book_navy_1795012459296.jpg',
        featuredOnHome: false,
        order: 10,
        active: true,
      },
      {
        id: 'svc-visibility-audits',
        title: 'Book Visibility Audits',
        slug: 'book-visibility-audits',
        shortDescription:
          'Detailed diagnostic reviews of your book’s positioning, retail presence, and author platform with actionable steps.',
        fullDescription:
          'If your book is not gaining the traction it deserves, guesswork is costly. Our Book Visibility Audit examines your cover-to-blurb alignment, website, Goodreads presence, and Amazon footprint—delivering a clear, prioritized action plan you can execute with confidence.',
        deliverables: [
          'Written diagnostic report covering cover, blurb, and positioning',
          'Author website, Goodreads, and Amazon credibility review',
          'Competitive genre benchmark comparison',
          'Prioritized 30-day and 90-day improvement roadmap',
        ],
        imageUrl: '/src/assets/images/hero_literary_agency_1795012457583.jpg',
        featuredOnHome: false,
        order: 11,
        active: true,
      },
    ],
    portfolio: [
      {
        id: 'port-1',
        projectTitle: 'Showcase Campaign: Literary Fiction Hardcover Launch',
        authorName: 'Agency Showcase Sample',
        bookTitle: 'The Silent Geometry',
        bookCoverUrl: '/src/assets/images/featured_book_navy_1795012459296.jpg',
        bannerImageUrl: '/src/assets/images/hero_literary_agency_1795012457583.jpg',
        videoUrl: '',
        videoType: 'none',
        description:
          'Demonstrator campaign showcasing bespoke midnight-navy and gold foil banner presentation, retail positioning copy, and editorial spotlight layout for contemporary literary fiction.',
        category: 'Promotional Banners',
        publicationDate: '2026-09-15',
        featuredOnHome: true,
        createdAt: now,
      },
      {
        id: 'port-2',
        projectTitle: 'Showcase Production: Atmospheric Suspense Book Trailer',
        authorName: 'Agency Showcase Sample',
        bookTitle: 'The Silence of Shadows',
        bookCoverUrl: '/src/assets/images/featured_book_charcoal_1795012459934.jpg',
        bannerImageUrl: '/src/assets/images/service_book_trailer_1795012459207.jpg',
        videoUrl: '',
        videoType: 'none',
        description:
          'Studio trailer production showcase illustrating cinematic title pacing, moody visual grading, and high-contrast promotional framing for thriller and suspense releases.',
        category: 'Book Trailers',
        publicationDate: '2026-08-22',
        featuredOnHome: true,
        createdAt: now,
      },
      {
        id: 'port-3',
        projectTitle: 'Showcase Feature: Author Editorial Spotlight & Press Suite',
        authorName: 'Agency Showcase Sample',
        bookTitle: 'Architectural Dialogues',
        bookCoverUrl: '/src/assets/images/featured_book_charcoal_1795012459934.jpg',
        bannerImageUrl: '/src/assets/images/service_author_spotlight_1795012457843.jpg',
        videoUrl: '',
        videoType: 'none',
        description:
          'Editorial spotlight layout pairing long-form author narrative storytelling with tactile manuscript photography for nonfiction and design-focused works.',
        category: 'Author Spotlight Features',
        publicationDate: '2026-07-10',
        featuredOnHome: true,
        createdAt: now,
      },
    ],
    featuredBooks: [
      {
        id: 'book-silent-geometry',
        bookTitle: 'The Silent Geometry',
        authorName: 'Evelyn Reed (Showcase Edition)',
        genre: 'Literary Fiction',
        shortDescription:
          'An atmospheric literary novel exploring memory, architecture, and unspoken family legacies—presented through an agency showcase campaign highlighting hardcover branding and editorial positioning.',
        promotionalNotes:
          'Promotional package includes custom spotlight banner graphics, Amazon category & keyword alignment blueprint, and reader discussion guide assets.',
        bookCoverUrl: '/src/assets/images/featured_book_navy_1795012459296.jpg',
        promotionalBannerUrl: '/src/assets/images/hero_literary_agency_1795012457583.jpg',
        trailerUrl: '',
        purchaseLink: '',
        spotlightStory:
          'Positioned for readers of contemplative contemporary fiction, this showcase campaign demonstrates how restrained navy-and-gold visual typography communicates prestige across digital storefronts and social banners.',
        featuredOnHome: true,
        createdAt: now,
      },
      {
        id: 'book-architectural-dialogues',
        bookTitle: 'Architectural Dialogues',
        authorName: 'The Design Collective (Showcase Edition)',
        genre: 'Art, Design & Nonfiction',
        shortDescription:
          'A curated monograph on elegance in spatial form—featured as an agency demonstrator for nonfiction visibility audits, press-ready banners, and retail presentation.',
        promotionalNotes:
          'Promotional package includes Author Spotlight feature architecture, A+ visual layout concept, and targeted design-community outreach strategy.',
        bookCoverUrl: '/src/assets/images/featured_book_charcoal_1795012459934.jpg',
        promotionalBannerUrl: '/src/assets/images/service_author_spotlight_1795012457843.jpg',
        trailerUrl: '',
        purchaseLink: '',
        spotlightStory:
          'Nonfiction titles thrive on authority and visual clarity. Our promotional feature highlights the book’s tactile craftsmanship while structuring its synopsis for high conversion among design professionals and collectors.',
        featuredOnHome: true,
        createdAt: now,
      },
    ],
    authors: [
      {
        id: 'author-edward-sample',
        fullName: 'Evelyn Reed (Showcase Profile)',
        penName: 'Evelyn Reed',
        genres: ['Literary Fiction', 'Historical Drama'],
        bio: 'Sample author profile demonstrating how featured authors are presented with biography, genre focus, and connected promotional campaigns. Replace or add real client profiles anytime in the Admin Dashboard.',
        photoUrl: '/src/assets/images/service_author_spotlight_1795012457843.jpg',
        website: '',
        socialLink: '',
        featuredBooksCount: 1,
        createdAt: now,
      },
    ],
    testimonials: [
      {
        id: 'test-placeholder-1',
        authorName: 'Verified Author Review Placeholder',
        authorPhotoUrl: '',
        bookTitle: 'Your Book Title Here',
        bookCoverUrl: '/src/assets/images/featured_book_navy_1795012459296.jpg',
        testimonialText:
          'This clearly marked placeholder reserves space for genuine, verified feedback from an author who has completed a promotional campaign with Edward Duncan Book Promotions. Replace, unpublish, or add real client testimonials anytime from the private Admin Dashboard.',
        authorLink: '',
        rating: undefined,
        published: true,
        isPlaceholder: true,
        createdAt: now,
      },
      {
        id: 'test-placeholder-2',
        authorName: 'Client Testimonial Slot (Awaiting Genuine Feedback)',
        authorPhotoUrl: '',
        bookTitle: 'Upcoming Author Feature',
        bookCoverUrl: '/src/assets/images/featured_book_charcoal_1795012459934.jpg',
        testimonialText:
          'We never publish fabricated quotes. Once an author submits their authentic campaign review, Edward Duncan publishes it here with full attribution, book cover, and optional author website link.',
        authorLink: '',
        rating: undefined,
        published: true,
        isPlaceholder: true,
        createdAt: now,
      },
    ],
    contactSubmissions: [],
    mediaLibrary: [
      {
        id: 'media-seed-1',
        filename: 'hero_literary_agency_1795012457583.jpg',
        originalName: 'hero_literary_agency.jpg',
        url: '/src/assets/images/hero_literary_agency_1795012457583.jpg',
        mimeType: 'image/jpeg',
        sizeBytes: 0,
        assetType: 'banner',
        title: 'Literary Agency Hero Backdrop',
        createdAt: now,
      },
      {
        id: 'media-seed-2',
        filename: 'edward_duncan_portrait_1795012457373.jpg',
        originalName: 'edward_duncan_portrait.jpg',
        url: '/src/assets/images/edward_duncan_portrait_1795012457373.jpg',
        mimeType: 'image/jpeg',
        sizeBytes: 0,
        assetType: 'author_photo',
        title: 'Edward Duncan Editorial Portrait',
        createdAt: now,
      },
      {
        id: 'media-seed-3',
        filename: 'service_author_spotlight_1795012457843.jpg',
        originalName: 'service_author_spotlight.jpg',
        url: '/src/assets/images/service_author_spotlight_1795012457843.jpg',
        mimeType: 'image/jpeg',
        sizeBytes: 0,
        assetType: 'banner',
        title: 'Author Spotlight Editorial Still Life',
        createdAt: now,
      },
      {
        id: 'media-seed-4',
        filename: 'service_book_trailer_1795012459207.jpg',
        originalName: 'service_book_trailer.jpg',
        url: '/src/assets/images/service_book_trailer_1795012459207.jpg',
        mimeType: 'image/jpeg',
        sizeBytes: 0,
        assetType: 'banner',
        title: 'Book Trailer Production Suite',
        createdAt: now,
      },
      {
        id: 'media-seed-5',
        filename: 'featured_book_navy_1795012459296.jpg',
        originalName: 'featured_book_navy.jpg',
        url: '/src/assets/images/featured_book_navy_1795012459296.jpg',
        mimeType: 'image/jpeg',
        sizeBytes: 0,
        assetType: 'book_cover',
        title: 'The Silent Geometry Hardcover',
        createdAt: now,
      },
      {
        id: 'media-seed-6',
        filename: 'featured_book_charcoal_1795012459934.jpg',
        originalName: 'featured_book_charcoal.jpg',
        url: '/src/assets/images/featured_book_charcoal_1795012459934.jpg',
        mimeType: 'image/jpeg',
        sizeBytes: 0,
        assetType: 'book_cover',
        title: 'Architectural Dialogues Hardcover',
        createdAt: now,
      },
    ],
  };

  return { db, initialRecoveryKey, initialPassword };
}

let cachedDb: DatabaseSchema | null = null;

function ensureDirs(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function hydrateMissingFields(db: DatabaseSchema): boolean {
  let changed = false;
  if (!db.pagesCopy) {
    db.pagesCopy = createDefaultPagesCopy();
    changed = true;
  } else {
    const defaults = createDefaultPagesCopy();
    for (const key of Object.keys(defaults) as (keyof PagesCopyContent)[]) {
      if (db.pagesCopy[key] === undefined) {
        db.pagesCopy[key] = defaults[key];
        changed = true;
      }
    }
  }

  const homeExt = createDefaultHomepageExtensions();
  for (const key of Object.keys(homeExt) as (keyof typeof homeExt)[]) {
    if ((db.homepage as unknown as Record<string, unknown>)[key] === undefined) {
      (db.homepage as unknown as Record<string, unknown>)[key] = homeExt[key];
      changed = true;
    }
  }

  const aboutExt = createDefaultAboutExtensions();
  for (const key of Object.keys(aboutExt) as (keyof typeof aboutExt)[]) {
    if ((db.about as unknown as Record<string, unknown>)[key] === undefined) {
      (db.about as unknown as Record<string, unknown>)[key] = aboutExt[key];
      changed = true;
    }
  }

  return changed;
}

export function loadDatabase(): DatabaseSchema {
  if (cachedDb) {
    return cachedDb;
  }
  ensureDirs();
  if (!fs.existsSync(DB_PATH)) {
    const { db, initialRecoveryKey } = createInitialSeed();
    saveDatabase(db);
    console.log(`[INIT] Created owner account for ${db.owner.email}`);
    console.log(`[INIT] Owner Recovery Key (save securely): ${initialRecoveryKey}`);
    cachedDb = db;
    return db;
  }
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  const parsed = JSON.parse(raw) as DatabaseSchema;
  if (hydrateMissingFields(parsed)) {
    saveDatabase(parsed);
  }
  cachedDb = parsed;
  return parsed;
}

export function saveDatabase(db: DatabaseSchema): void {
  ensureDirs();
  const tmpPath = `${DB_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(db, null, 2), 'utf-8');
  fs.renameSync(tmpPath, DB_PATH);
  cachedDb = db;
}

export function getPublicSiteData(db: DatabaseSchema): PublicSiteData {
  return {
    settings: db.settings,
    homepage: db.homepage,
    about: db.about,
    pagesCopy: db.pagesCopy,
    services: [...db.services].filter((s) => s.active).sort((a, b) => a.order - b.order),
    portfolio: [...db.portfolio].sort((a, b) => b.publicationDate.localeCompare(a.publicationDate)),
    featuredBooks: [...db.featuredBooks],
    authors: [...db.authors],
    testimonials: db.testimonials.filter((t) => t.published),
  };
}
