import crypto from 'node:crypto';

export function hashPassword(password: string, existingSalt?: string): { salt: string; hash: string } {
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64);
  return { salt, hash: derived.toString('hex') };
}

export function verifyPassword(password: string, salt: string, expectedHashHex: string): boolean {
  if (!password || !salt || !expectedHashHex) {
    return false;
  }
  const derived = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHashHex, 'hex');
  if (derived.length !== expected.length) {
    return false;
  }
  return crypto.timingSafeEqual(derived, expected);
}

export function hashToken(rawToken: string): string {
  return crypto.createHash('sha256').update(rawToken).digest('hex');
}

export function generateSessionToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function generateRecoveryKey(): string {
  const bytes = crypto.randomBytes(12).toString('hex').toUpperCase();
  return `EDBP-${bytes.slice(0, 6)}-${bytes.slice(6, 12)}-${bytes.slice(12, 18)}-${bytes.slice(18, 24)}`;
}

export function generateResetCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = crypto.randomBytes(8);
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += chars[bytes[i] % chars.length];
  }
  return `${code.slice(0, 4)}-${code.slice(4, 8)}`;
}

export function signSessionValue(token: string, secret: string): string {
  const sig = crypto.createHmac('sha256', secret).update(token).digest('hex');
  return `${token}.${sig}`;
}

export function verifySignedSessionValue(cookieVal: string | undefined, secret: string): string | null {
  if (!cookieVal || typeof cookieVal !== 'string') {
    return null;
  }
  const dotIdx = cookieVal.lastIndexOf('.');
  if (dotIdx <= 0) {
    return null;
  }
  const token = cookieVal.slice(0, dotIdx);
  const sig = cookieVal.slice(dotIdx + 1);
  if (!token || !sig) {
    return null;
  }
  const expectedSig = crypto.createHmac('sha256', secret).update(token).digest('hex');
  const sigBuf = Buffer.from(sig, 'hex');
  const expectedBuf = Buffer.from(expectedSig, 'hex');
  if (sigBuf.length !== expectedBuf.length) {
    return null;
  }
  if (!crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }
  return token;
}
